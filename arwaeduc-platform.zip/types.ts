
export enum Role {
  SUPER_ADMIN = 'SUPER_ADMIN',
  ADMIN = 'ADMIN',
  TEACHER = 'TEACHER',
  STUDENT = 'STUDENT',
  SECRETARY = 'SECRETARY',
  PARENT = 'PARENT',
}

export enum SubscriptionPack {
  SIMPLE = 'SIMPLE',
  STARTER = 'STARTER',
  BUSINESS = 'BUSINESS',
}

export enum SubscriptionStatus {
  ACTIVE = 'ACTIVE',
  PENDING = 'PENDING',
  CANCELED = 'CANCELED',
}

export enum PaymentStatus {
  COMPLETED = 'COMPLETED',
  PENDING = 'PENDING',
  FAILED = 'FAILED',
}

export enum FormationCategory {
  SCOLAIRE_SOUTIEN = 'SCOLAIRE_SOUTIEN',
  TRAINING = 'TRAINING',
  LANGUES = 'LANGUES',
  OTHERS = 'OTHERS',
}

export interface Profile {
  id: number;
  userId: number;
  firstName: string;
  lastName: string;
  phone?: string;
  address?: string;
  socialMediaLink?: string;
  documents?: string[];
  childIds?: number[];
}

export interface User {
  id: number;
  email: string;
  role: Role;
  schoolId?: number;
  profile: Profile;
  createdAt: string; // ISO date string
}

export interface School {
  id: number;
  name: string;
  address?: string;
  subscriptionPack: SubscriptionPack;
  subscriptionStatus: SubscriptionStatus;
  featureOverrides?: {
    adminDashboard?: boolean;
    parentDashboard?: boolean;
  };
}

export interface Course {
  id: number;
  title: string;
  description: string;
  schoolId: number;
  teacherId: number;
  studentIds: number[];
  schedule: string[]; // Array of ISO date strings
  category?: FormationCategory;
  details?: string;
}

export interface Payment {
  id: number;
  userId: number;
  amount: number;
  currency: string;
  status: PaymentStatus;
  createdAt: string; // ISO date string
}

export interface SpacePackLimits {
  maxStudents: number;
  maxCourses: number;
  maxTeachers: number;
  maxSecretaries: number;
  adminDashboard: boolean;
  parentDashboard: boolean;
  features: string[];
}
