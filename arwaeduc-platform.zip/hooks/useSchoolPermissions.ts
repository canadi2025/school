import { useMemo } from 'react';
import { Role } from '../types';
import { useData } from '../context/DataContext';

const defaultLimits = {
  maxStudents: Infinity,
  maxCourses: Infinity,
  maxTeachers: Infinity,
  maxSecretaries: Infinity,
  adminDashboard: true,
  parentDashboard: true,
  features: [],
};

const defaultUsage = {
    students: 0,
    courses: 0,
    teachers: 0,
    secretaries: 0,
};

export const useSchoolPermissions = (schoolId?: number) => {
  const { users, courses, schools, spacePacks } = useData();

  const permissions = useMemo(() => {
    if (!schoolId || !schools.length || !spacePacks) {
      return {
        canAddStudent: true, canAddCourse: true, canAddTeacher: true, canAddSecretary: true,
        hasAdminDashboard: true, hasParentDashboard: true,
        limits: defaultLimits, usage: defaultUsage,
      };
    }

    const school = schools.find(s => s.id === schoolId);
    const packLimits = school ? spacePacks[school.subscriptionPack] : defaultLimits;

    const schoolUsers = users.filter(u => u.schoolId === schoolId);
    const schoolCourses = courses.filter(c => c.schoolId === schoolId);
    
    const usage = {
        students: schoolUsers.filter(u => u.role === Role.STUDENT).length,
        courses: schoolCourses.length,
        teachers: schoolUsers.filter(u => u.role === Role.TEACHER).length,
        secretaries: schoolUsers.filter(u => u.role === Role.SECRETARY).length,
    };
    
    const hasAdminDashboard = school?.featureOverrides?.adminDashboard !== undefined
        ? school.featureOverrides.adminDashboard
        : packLimits.adminDashboard;
        
    const hasParentDashboard = school?.featureOverrides?.parentDashboard !== undefined
        ? school.featureOverrides.parentDashboard
        : packLimits.parentDashboard;

    return {
      canAddStudent: usage.students < packLimits.maxStudents,
      canAddCourse: usage.courses < packLimits.maxCourses,
      canAddTeacher: usage.teachers < packLimits.maxTeachers,
      canAddSecretary: usage.secretaries < packLimits.maxSecretaries,
      hasAdminDashboard,
      hasParentDashboard,
      limits: packLimits,
      usage,
    };
  }, [schoolId, users, courses, schools, spacePacks]);

  return { permissions, usage: permissions.usage, limits: permissions.limits };
};
