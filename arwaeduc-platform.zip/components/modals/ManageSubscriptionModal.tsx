import React, { useState, useEffect } from 'react';
import { School, SubscriptionPack, SubscriptionStatus } from '../../types';
import { useData } from '../../context/DataContext';

interface ManageSubscriptionModalProps {
  school: School;
  onClose: () => void;
  onUpdate: (schoolId: number, pack: SubscriptionPack, status: SubscriptionStatus, featureOverrides: School['featureOverrides']) => void;
}

const packColors: Record<SubscriptionPack, string> = {
  [SubscriptionPack.SIMPLE]: 'text-blue-600',
  [SubscriptionPack.STARTER]: 'text-purple-600',
  [SubscriptionPack.BUSINESS]: 'text-green-600',
};

const FeatureToggle: React.FC<{ label: string; checked: boolean; onChange: (checked: boolean) => void }> = ({ label, checked, onChange }) => (
    <label className="flex items-center justify-between p-3 bg-gray-50 rounded-md hover:bg-gray-100 transition-colors">
        <span className="text-sm font-medium text-gray-700">{label}</span>
        <input
            type="checkbox"
            checked={checked}
            onChange={(e) => onChange(e.target.checked)}
            className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
        />
    </label>
);

const ManageSubscriptionModal: React.FC<ManageSubscriptionModalProps> = ({ school, onClose, onUpdate }) => {
  const [pack, setPack] = useState<SubscriptionPack>(school.subscriptionPack);
  const [status, setStatus] = useState<SubscriptionStatus>(school.subscriptionStatus);
  const [featureOverrides, setFeatureOverrides] = useState<School['featureOverrides']>(school.featureOverrides || {});
  const { spacePacks } = useData();

  useEffect(() => {
    // When the pack changes, merge existing overrides with the new pack's defaults
    if (spacePacks) {
        const packDefaults = spacePacks[pack];
        setFeatureOverrides(prevOverrides => ({
          adminDashboard: prevOverrides.adminDashboard ?? packDefaults.adminDashboard,
          parentDashboard: prevOverrides.parentDashboard ?? packDefaults.parentDashboard,
        }));
    }
  }, [pack, spacePacks]);

  const handleFeatureChange = (feature: keyof School['featureOverrides'], value: boolean) => {
    setFeatureOverrides(prev => ({ ...prev, [feature]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdate(school.id, pack, status, featureOverrides);
  };
  
  const selectedPackDetails = spacePacks ? spacePacks[pack] : null;

  if (!selectedPackDetails) {
    return null; // or a loading indicator
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4 page-transition">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <div>
            <h2 className="text-xl font-semibold text-gray-800">Manage Subscription</h2>
            <p className="text-sm text-gray-500">
                For: <span className="font-bold">{school.name}</span>
            </p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="subPack" className="block text-sm font-medium text-gray-700 mb-1">
                  Subscription Pack
                </label>
                <select
                  id="subPack"
                  value={pack}
                  onChange={(e) => setPack(e.target.value as SubscriptionPack)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                >
                  {Object.values(SubscriptionPack).map(p => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="subStatus" className="block text-sm font-medium text-gray-700 mb-1">
                  Subscription Status
                </label>
                <select
                  id="subStatus"
                  value={status}
                  onChange={(e) => setStatus(e.target.value as SubscriptionStatus)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                >
                  {Object.values(SubscriptionStatus).map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="p-4 border border-gray-200 rounded-lg">
                <h3 className={`font-bold text-lg mb-3 capitalize ${packColors[pack]}`}>{pack.toLowerCase()} Pack Details</h3>
                
                <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm text-gray-600 mb-4">
                    <p><strong>Students:</strong> {isFinite(selectedPackDetails.maxStudents) ? selectedPackDetails.maxStudents : 'Unlimited'}</p>
                    <p><strong>Teachers:</strong> {isFinite(selectedPackDetails.maxTeachers) ? selectedPackDetails.maxTeachers : 'Unlimited'}</p>
                    <p><strong>Courses:</strong> {isFinite(selectedPackDetails.maxCourses) ? selectedPackDetails.maxCourses : 'Unlimited'}</p>
                    <p><strong>Secretaries:</strong> {isFinite(selectedPackDetails.maxSecretaries) ? selectedPackDetails.maxSecretaries : 'Unlimited'}</p>
                </div>
              
                <div className="pt-4 border-t">
                     <h4 className="font-semibold text-gray-700 mb-2">Permissions & Feature Overrides</h4>
                     <div className="space-y-2">
                        <FeatureToggle
                            label="Admin Dashboard Access"
                            checked={featureOverrides?.adminDashboard ?? false}
                            onChange={(val) => handleFeatureChange('adminDashboard', val)}
                        />
                         <FeatureToggle
                            label="Parent Dashboard Access"
                            checked={featureOverrides?.parentDashboard ?? false}
                            onChange={(val) => handleFeatureChange('parentDashboard', val)}
                        />
                     </div>
                </div>
            </div>

          </div>
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-end space-x-3 rounded-b-lg">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-opacity-50 transition-colors"
            >
              Update Subscription
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ManageSubscriptionModal;