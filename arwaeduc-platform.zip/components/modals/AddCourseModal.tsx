import React, { useState, useMemo } from 'react';
import { Course, User, School, Role, FormationCategory } from '../../types';

interface AddCourseModalProps {
  onClose: () => void;
  onAddCourse: (courseData: Omit<Course, 'id' | 'studentIds'>) => void;
  user: User;
  users: User[];
  schools: School[];
  context?: 'course' | 'formation';
}

const AddCourseModal: React.FC<AddCourseModalProps> = ({ onClose, onAddCourse, user, users, schools, context = 'course' }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [schoolId, setSchoolId] = useState<string>(user.schoolId ? String(user.schoolId) : '');
  const [teacherId, setTeacherId] = useState<string>('');
  const [category, setCategory] = useState<FormationCategory | ''>('');
  const [details, setDetails] = useState('');
  const [error, setError] = useState('');

  const availableTeachers = useMemo(() => {
    const targetSchoolId = parseInt(schoolId, 10);
    if (!targetSchoolId) return [];
    return users.filter(u => u.role === Role.TEACHER && u.schoolId === targetSchoolId);
  }, [schoolId, users]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !schoolId || !teacherId || (context === 'formation' && !category)) {
      setError('Title, school, teacher, and category (for formations) are required.');
      return;
    }
    setError('');
    onAddCourse({
      title,
      description,
      schoolId: parseInt(schoolId, 10),
      teacherId: parseInt(teacherId, 10),
      schedule: [],
      category: context === 'formation' ? category as FormationCategory : undefined,
      details: context === 'formation' ? details : undefined,
    });
  };

  const modalTitle = context === 'formation' ? 'Add New Formation' : 'Add New Course';
  const submitButtonText = context === 'formation' ? 'Add Formation' : 'Add Course';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4 page-transition">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">{modalTitle}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">Title <span className="text-red-500">*</span></label>
              <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500" autoFocus />
            </div>
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <textarea id="description" value={description} onChange={e => setDescription(e.target.value)} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500" />
            </div>
            {user.role === Role.SUPER_ADMIN && (
              <div>
                <label htmlFor="school" className="block text-sm font-medium text-gray-700 mb-1">School <span className="text-red-500">*</span></label>
                <select id="school" value={schoolId} onChange={e => { setSchoolId(e.target.value); setTeacherId(''); }} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500">
                  <option value="">-- Select School --</option>
                  {schools.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
            )}
             {context === 'formation' && (
              <>
                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">Category <span className="text-red-500">*</span></label>
                  <select id="category" value={category} onChange={e => setCategory(e.target.value as FormationCategory)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm">
                    <option value="">-- Select Category --</option>
                    {Object.values(FormationCategory).map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="details" className="block text-sm font-medium text-gray-700 mb-1">Details</label>
                  <textarea id="details" value={details} onChange={e => setDetails(e.target.value)} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500" placeholder="Add specific details about this formation..."/>
                </div>
              </>
            )}
            <div>
              <label htmlFor="teacher" className="block text-sm font-medium text-gray-700 mb-1">Teacher <span className="text-red-500">*</span></label>
              <select id="teacher" value={teacherId} onChange={e => setTeacherId(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500" disabled={!schoolId}>
                <option value="">-- Select Teacher --</option>
                {availableTeachers.map(t => <option key={t.id} value={t.id}>{t.profile.firstName} {t.profile.lastName}</option>)}
              </select>
            </div>
            {error && <p className="text-sm text-red-600">{error}</p>}
          </div>
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-end space-x-3 rounded-b-lg">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-opacity-50 transition-colors">{submitButtonText}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddCourseModal;
