import React, { useState, useEffect } from 'react';
import { SubscriptionPack, SpacePackLimits } from '../../types';

interface EditSpacePackModalProps {
  pack: SubscriptionPack;
  limits: SpacePackLimits;
  onClose: () => void;
  onUpdate: (pack: SubscriptionPack, limits: SpacePackLimits) => void;
}

interface FormState {
  maxStudents: string;
  maxCourses: string;
  maxTeachers: string;
  maxSecretaries: string;
  adminDashboard: boolean;
  parentDashboard: boolean;
  features: string;
}

const EditSpacePackModal: React.FC<EditSpacePackModalProps> = ({ pack, limits, onClose, onUpdate }) => {
  const [formState, setFormState] = useState<FormState>({
    maxStudents: '',
    maxCourses: '',
    maxTeachers: '',
    maxSecretaries: '',
    adminDashboard: true,
    parentDashboard: false,
    features: '',
  });

  useEffect(() => {
    setFormState({
      maxStudents: isFinite(limits.maxStudents) ? String(limits.maxStudents) : 'Unlimited',
      maxCourses: isFinite(limits.maxCourses) ? String(limits.maxCourses) : 'Unlimited',
      maxTeachers: isFinite(limits.maxTeachers) ? String(limits.maxTeachers) : 'Unlimited',
      maxSecretaries: isFinite(limits.maxSecretaries) ? String(limits.maxSecretaries) : 'Unlimited',
      adminDashboard: limits.adminDashboard,
      parentDashboard: limits.parentDashboard,
      features: limits.features.join(', '),
    });
  }, [limits]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const isCheckbox = type === 'checkbox';
    
    setFormState(prevState => ({ 
        ...prevState, 
        [name]: isCheckbox ? (e.target as HTMLInputElement).checked : value 
    }));
  };

  const handleUnlimitedToggle = (field: keyof Omit<FormState, 'adminDashboard' | 'parentDashboard' | 'features'>) => {
    setFormState(prevState => ({
      ...prevState,
      [field]: prevState[field] === 'Unlimited' ? '0' : 'Unlimited',
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newLimits: SpacePackLimits = {
      maxStudents: formState.maxStudents === 'Unlimited' ? Infinity : parseInt(formState.maxStudents, 10) || 0,
      maxCourses: formState.maxCourses === 'Unlimited' ? Infinity : parseInt(formState.maxCourses, 10) || 0,
      maxTeachers: formState.maxTeachers === 'Unlimited' ? Infinity : parseInt(formState.maxTeachers, 10) || 0,
      maxSecretaries: formState.maxSecretaries === 'Unlimited' ? Infinity : parseInt(formState.maxSecretaries, 10) || 0,
      adminDashboard: formState.adminDashboard,
      parentDashboard: formState.parentDashboard,
      features: formState.features.split(',').map(f => f.trim()).filter(Boolean),
    };
    onUpdate(pack, newLimits);
  };
  
  const renderInput = (id: 'maxStudents' | 'maxCourses' | 'maxTeachers' | 'maxSecretaries', label: string) => (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <div className="flex items-center space-x-2">
        <input
          type="number"
          id={id}
          name={id}
          value={formState[id] === 'Unlimited' ? '' : formState[id]}
          onChange={handleInputChange}
          disabled={formState[id] === 'Unlimited'}
          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 disabled:bg-gray-100"
        />
        <label className="flex items-center flex-shrink-0">
            <input 
                type="checkbox"
                checked={formState[id] === 'Unlimited'}
                onChange={() => handleUnlimitedToggle(id)}
                className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
            />
            <span className="ml-2 text-sm text-gray-600">Unlimited</span>
        </label>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4 page-transition">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">Edit <span className="capitalize">{pack.toLowerCase()}</span> Pack</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {renderInput('maxStudents', 'Max Students')}
                {renderInput('maxCourses', 'Max Courses')}
                {renderInput('maxTeachers', 'Max Teachers')}
                {renderInput('maxSecretaries', 'Max Secretaries')}
            </div>
            <div className="border-t pt-4">
                 <label className="block text-sm font-medium text-gray-700 mb-2">Dashboard Access</label>
                 <div className="space-y-2">
                    <label className="flex items-center">
                        <input 
                            type="checkbox"
                            name="adminDashboard"
                            checked={formState.adminDashboard}
                            onChange={handleInputChange}
                            className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                        />
                        <span className="ml-2 text-sm text-gray-600">Admin Dashboard</span>
                    </label>
                     <label className="flex items-center">
                        <input 
                            type="checkbox"
                            name="parentDashboard"
                            checked={formState.parentDashboard}
                            onChange={handleInputChange}
                            className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                        />
                        <span className="ml-2 text-sm text-gray-600">Parent Dashboard</span>
                    </label>
                 </div>
            </div>
             <div className="border-t pt-4">
                <label htmlFor="features" className="block text-sm font-medium text-gray-700 mb-1">Additional Features</label>
                <textarea
                    id="features"
                    name="features"
                    value={formState.features}
                    onChange={handleInputChange}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                    placeholder="e.g., Automated Backups, Priority Support"
                />
                <p className="text-xs text-gray-500 mt-1">Enter features separated by commas.</p>
             </div>
          </div>
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-end space-x-3 rounded-b-lg">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-opacity-50 transition-colors"
            >
              Save Changes
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditSpacePackModal;