import React, { useState, useMemo } from 'react';
import { School, Course, User, Role } from '../../types';

interface EnrollStudentModalProps {
  school: School;
  allCourses: Course[];
  allUsers: User[];
  onClose: () => void;
  onEnroll: (courseId: number, studentId: number) => void;
}

const EnrollStudentModal: React.FC<EnrollStudentModalProps> = ({ school, allCourses, allUsers, onClose, onEnroll }) => {
  const [selectedCourseId, setSelectedCourseId] = useState<string>('');
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [error, setError] = useState('');

  const schoolCourses = useMemo(() => 
    allCourses.filter(course => course.schoolId === school.id),
    [allCourses, school.id]
  );
  
  const availableStudents = useMemo(() => {
    if (!selectedCourseId) return [];
    
    const course = allCourses.find(c => c.id === parseInt(selectedCourseId, 10));
    if (!course) return [];

    return allUsers.filter(user => 
      user.role === Role.STUDENT &&
      user.schoolId === school.id &&
      !course.studentIds.includes(user.id)
    );
  }, [selectedCourseId, allCourses, allUsers, school.id]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCourseId || !selectedStudentId) {
      setError('Please select both a course and a student.');
      return;
    }
    setError('');
    onEnroll(parseInt(selectedCourseId, 10), parseInt(selectedStudentId, 10));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4 page-transition">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">Enroll Student in {school.name}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-6 space-y-4">
            <div>
              <label htmlFor="courseSelect" className="block text-sm font-medium text-gray-700 mb-1">
                Select Course <span className="text-red-500">*</span>
              </label>
              <select
                id="courseSelect"
                value={selectedCourseId}
                onChange={(e) => {
                  setSelectedCourseId(e.target.value);
                  setSelectedStudentId('');
                }}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
              >
                <option value="">-- Choose a course --</option>
                {schoolCourses.map(course => (
                  <option key={course.id} value={course.id}>{course.title}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="studentSelect" className="block text-sm font-medium text-gray-700 mb-1">
                Select Student <span className="text-red-500">*</span>
              </label>
              <select
                id="studentSelect"
                value={selectedStudentId}
                onChange={(e) => setSelectedStudentId(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                disabled={!selectedCourseId || availableStudents.length === 0}
              >
                <option value="">-- Choose a student --</option>
                {availableStudents.map(student => (
                  <option key={student.id} value={student.id}>
                    {student.profile.firstName} {student.profile.lastName}
                  </option>
                ))}
              </select>
               {selectedCourseId && availableStudents.length === 0 && (
                <p className="text-xs text-gray-500 mt-1">All eligible students are already enrolled in this course.</p>
              )}
            </div>
            {error && <p className="text-sm text-red-600 mt-2">{error}</p>}
          </div>
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-end space-x-3 rounded-b-lg">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!selectedCourseId || !selectedStudentId}
              className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-opacity-50 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              Enroll Student
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EnrollStudentModal;