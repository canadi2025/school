
import React, { useState, useMemo } from 'react';
import { Role, School, User, Profile } from '../../types';
import { useData } from '../../context/DataContext';

interface AddUserModalProps {
  onClose: () => void;
  onAddUser: (userData: {
    firstName: string;
    lastName: string;
    email: string;
    role: Role;
    schoolId?: number;
    profile: Omit<Profile, 'id' | 'userId' | 'firstName' | 'lastName'>;
  }) => void;
  currentUser: User;
  schools?: School[];
  defaultRole?: Role;
}

const AddUserModal: React.FC<AddUserModalProps> = ({ onClose, onAddUser, currentUser, schools = [], defaultRole }) => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<Role | ''>(defaultRole || '');
  const [schoolId, setSchoolId] = useState<string>(currentUser.role !== Role.SUPER_ADMIN ? String(currentUser.schoolId) : '');
  const [childIds, setChildIds] = useState<number[]>([]);
  const [error, setError] = useState('');

  const { users } = useData();

  const schoolStudents = useMemo(() => {
    const targetSchoolId = parseInt(schoolId, 10);
    if (!targetSchoolId || role !== Role.PARENT) return [];
    return users.filter(u => u.schoolId === targetSchoolId && u.role === Role.STUDENT);
  }, [schoolId, users, role]);

  const handleChildSelection = (studentId: number) => {
    setChildIds(prev => prev.includes(studentId) ? prev.filter(id => id !== studentId) : [...prev, studentId]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim() || !lastName.trim() || !email.trim() || !role) {
      setError('First name, last name, email, and role are required.');
      return;
    }
    if (currentUser.role === Role.SUPER_ADMIN && !schoolId) {
        setError('School must be selected when creating a user as Super Admin.');
        return;
    }
    setError('');
    
    const userData = {
        firstName,
        lastName,
        email,
        role: role as Role,
        schoolId: schoolId ? parseInt(schoolId, 10) : undefined,
        profile: {
            ...(role === Role.PARENT && { childIds })
        }
    };
    onAddUser(userData);
  };
  
  const roleOptions = Object.values(Role).filter(r => r !== Role.SUPER_ADMIN);
  const inputClasses = "w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500";

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4 page-transition">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">Add New User</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">First Name <span className="text-red-500">*</span></label>
                <input type="text" value={firstName} onChange={e => setFirstName(e.target.value)} className={inputClasses} autoFocus />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Last Name <span className="text-red-500">*</span></label>
                <input type="text" value={lastName} onChange={e => setLastName(e.target.value)} className={inputClasses} />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email <span className="text-red-500">*</span></label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} className={inputClasses} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Role <span className="text-red-500">*</span></label>
                <select value={role} onChange={e => setRole(e.target.value as Role)} className={inputClasses} disabled={!!defaultRole}>
                  <option value="">-- Select Role --</option>
                  {roleOptions.map(r => <option key={r} value={r}>{r.charAt(0) + r.slice(1).toLowerCase()}</option>)}
                </select>
              </div>
              {currentUser.role === Role.SUPER_ADMIN && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">School <span className="text-red-500">*</span></label>
                  <select value={schoolId} onChange={e => setSchoolId(e.target.value)} className={inputClasses}>
                    <option value="">-- Select School --</option>
                    {schools.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
              )}
            </div>

            {role === Role.PARENT && schoolId && (
              <div className="border-t pt-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">Link Children (Optional)</label>
                {schoolStudents.length > 0 ? (
                  <div className="max-h-40 overflow-y-auto space-y-2 p-2 border rounded-md">
                    {schoolStudents.map(student => (
                      <label key={student.id} className="flex items-center space-x-2 cursor-pointer p-1 hover:bg-gray-50 rounded">
                        <input type="checkbox" checked={childIds.includes(student.id)} onChange={() => handleChildSelection(student.id)} className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500" />
                        <span>{student.profile.firstName} {student.profile.lastName}</span>
                      </label>
                    ))}
                  </div>
                ) : <p className="text-sm text-gray-500">No students found in the selected school to link.</p>}
              </div>
            )}
            
            {error && <p className="text-sm text-red-600 mt-2">{error}</p>}
          </div>
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-end space-x-3 rounded-b-lg">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-opacity-50 transition-colors">Add User</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddUserModal;
