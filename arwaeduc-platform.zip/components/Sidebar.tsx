import React from 'react';
import { NavLink } from 'react-router-dom';
import { Role, User } from '../types';
import { 
    DashboardIcon, SchoolIcon, UsersIcon, PaymentIcon, CoursesIcon, ServerIcon, SettingsIcon,
    AttendanceIcon, MaterialsIcon, ExamsIcon, ActivitiesIcon, BookIcon 
} from './icons/IconComponents';
import { useSchoolPermissions } from '../hooks/useSchoolPermissions';

interface SidebarProps {
  user: User;
}

const NavItem: React.FC<{ to: string; label: string; icon: React.FC<{ className?: string }> }> = ({ to, label, icon: Icon }) => (
  <NavLink
    to={to}
    className={({ isActive }) =>
      `flex items-center px-4 py-2.5 text-sm font-medium rounded-lg transition-colors duration-200 ${
        isActive
          ? 'bg-primary-500 text-white'
          : 'text-gray-600 hover:bg-primary-100 hover:text-primary-700'
      }`
    }
  >
    <Icon className="w-5 h-5 mr-3" />
    {label}
  </NavLink>
);

const Sidebar: React.FC<SidebarProps> = ({ user }) => {
  const { permissions } = useSchoolPermissions(user.schoolId);

  const commonLinks = [
    { to: '/dashboard', label: 'Dashboard', icon: DashboardIcon },
  ];

  const superAdminLinks = [
    { to: '/admin/schools', label: 'Schools', icon: SchoolIcon },
    { to: '/admin/users', label: 'Users', icon: UsersIcon },
    { to: '/admin/courses', label: 'Courses', icon: CoursesIcon },
    { to: '/admin/finance', label: 'Finance', icon: PaymentIcon },
    { to: '/admin/space-packs', label: 'Space Packs', icon: ServerIcon },
  ];

  const adminLinks = [
    { to: '/admin/users', label: 'School Users', icon: UsersIcon },
    { to: '/admin/teachers', label: 'Teachers', icon: UsersIcon },
    { to: '/admin/secretaries', label: 'Secretary', icon: UsersIcon },
    { to: '/admin/parents', label: 'Parents', icon: UsersIcon },
    { to: '/admin/students', label: 'Students', icon: UsersIcon },
    { to: '/admin/courses', label: 'Courses', icon: CoursesIcon },
    { to: '/admin/formations', label: 'Formations', icon: BookIcon },
    { to: '/admin/finance', label: 'Finance', icon: PaymentIcon },
    { to: '/admin/settings', label: 'Settings', icon: SettingsIcon },
  ];

  const teacherLinks = [
    { to: '/teacher/students', label: 'Students', icon: UsersIcon },
    { to: '/teacher/classes', label: 'Classes', icon: CoursesIcon },
    { to: '/teacher/attendance', label: 'Attendance', icon: AttendanceIcon },
    { to: '/teacher/exams', label: 'Exams', icon: ExamsIcon },
    { to: '/teacher/extra-activities', label: 'Extra Activities', icon: ActivitiesIcon },
  ];

  const studentLinks = [
    { to: '/student/courses', label: 'My Courses', icon: CoursesIcon },
    { to: '/student/billing', label: 'Billing', icon: PaymentIcon },
  ];

  const secretaryLinks = [
    { to: '/secretary/students', label: 'Students', icon: UsersIcon },
    { to: '/secretary/classes', label: 'Classes', icon: CoursesIcon },
    { to: '/secretary/formations', label: 'Formations', icon: BookIcon },
    { to: '/secretary/attendance', label: 'Attendance', icon: AttendanceIcon },
    { to: '/secretary/materials', label: 'Materials', icon: MaterialsIcon },
  ];

  const parentLinks = permissions.hasParentDashboard
    ? [{ to: '/parent/children', label: 'My Children', icon: UsersIcon }]
    : [];

  const roleLinks = {
    [Role.SUPER_ADMIN]: superAdminLinks,
    [Role.ADMIN]: adminLinks,
    [Role.TEACHER]: teacherLinks,
    [Role.STUDENT]: studentLinks,
    [Role.SECRETARY]: secretaryLinks,
    [Role.PARENT]: parentLinks,
  };
  
  const links = [...commonLinks, ...(roleLinks[user.role] || [])];

  return (
    <aside className="w-64 flex-shrink-0 bg-white border-r border-gray-200 flex flex-col">
      <div className="h-16 flex items-center px-6 border-b border-gray-200">
        <SchoolIcon className="h-8 w-8 text-primary-600" />
        <span className="ml-3 text-xl font-bold text-gray-800">EduSaaS</span>
      </div>
      <nav className="flex-1 px-4 py-6 space-y-2">
        {links.map((link) => (
          <NavItem key={link.to} {...link} />
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;