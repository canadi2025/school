import React from 'react';
import { useLocation } from 'react-router-dom';
import { User } from '../types';
import Sidebar from './Sidebar';
import Header from './Header';

interface DashboardLayoutProps {
  user: User;
  onLogout: () => void;
  children: React.ReactNode;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ user, onLogout, children }) => {
  const location = useLocation();

  return (
    <div className="h-screen flex bg-gray-50">
      <Sidebar user={user} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header user={user} onLogout={onLogout} />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50">
          <div key={location.pathname} className="container mx-auto px-6 py-8 page-transition">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;