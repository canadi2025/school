import React, { useState, useCallback } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { User, Role } from './types';
import * as api from './services/api';
import { DataProvider, useData } from './context/DataContext';

import LoginPage from './pages/LoginPage';
import DashboardLayout from './components/DashboardLayout';
import DashboardPage from './pages/DashboardPage';
import AdminSchoolsPage from './pages/admin/AdminSchoolsPage';
import AdminUsersPage from './pages/admin/AdminUsersPage';
import AdminCoursesPage from './pages/admin/AdminCoursesPage';
import AdminFinancePage from './pages/admin/AdminFinancePage';
import AdminSpacePacksPage from './pages/admin/AdminSpacePacksPage';
import TeacherStudentsPage from './pages/teacher/TeacherStudentsPage';
import StudentCoursesPage from './pages/student/StudentCoursesPage';
import StudentBillingPage from './pages/student/StudentBillingPage';
import SecretaryStudentsPage from './pages/secretary/SecretaryStudentsPage';
import MyChildrenPage from './pages/parent/MyChildrenPage';
import AdminTeachersPage from './pages/admin/AdminTeachersPage';
import AdminSecretariesPage from './pages/admin/AdminSecretariesPage';
import AdminParentsPage from './pages/admin/AdminParentsPage';
import AdminStudentsPage from './pages/admin/AdminStudentsPage';
import AdminSettingsPage from './pages/admin/AdminSettingsPage';
import SecretaryClassesPage from './pages/secretary/SecretaryCoursesPage';
import SecretaryAttendancePage from './pages/secretary/SecretaryAttendancePage';
import SecretaryMaterialsPage from './pages/secretary/SecretaryMaterialsPage';
import TeacherClassesPage from './pages/teacher/TeacherCoursesPage';
import TeacherAttendancePage from './pages/teacher/TeacherAttendancePage';
import TeacherExamsPage from './pages/teacher/TeacherExamsPage';
import TeacherExtraActivitiesPage from './pages/teacher/TeacherExtraActivitiesPage';
import TeacherDetailsPage from './pages/admin/TeacherDetailsPage';
import SecretaryDetailsPage from './pages/admin/SecretaryDetailsPage';
import AdminFormationsPage from './pages/admin/AdminFormationsPage';
import SecretaryFormationsPage from './pages/secretary/SecretaryFormationsPage';

const AppContent: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const { users } = useData();

  const handleLogin = useCallback((role: Role) => {
    // In a real app, this would be an API call. For now, find user from fetched data.
    const user = users.find(u => u.role === role);
    setCurrentUser(user || null);
  }, [users]);

  const handleLogout = useCallback(() => {
    setCurrentUser(null);
  }, []);

  if (!currentUser) {
    return <LoginPage onLogin={handleLogin} />;
  }
  
  return (
    <HashRouter>
      <DashboardLayout user={currentUser} onLogout={handleLogout}>
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<DashboardPage user={currentUser} />} />
          
          {/* Super Admin Routes */}
          {currentUser.role === Role.SUPER_ADMIN && (
            <>
              <Route path="/admin/schools" element={<AdminSchoolsPage user={currentUser} />} />
              <Route path="/admin/users" element={<AdminUsersPage user={currentUser}/>} />
              <Route path="/admin/courses" element={<AdminCoursesPage user={currentUser}/>} />
              <Route path="/admin/finance" element={<AdminFinancePage user={currentUser}/>} />
              <Route path="/admin/space-packs" element={<AdminSpacePacksPage />} />
            </>
          )}

          {/* Admin Routes */}
          {currentUser.role === Role.ADMIN && (
            <>
              <Route path="/admin/users" element={<AdminUsersPage user={currentUser} />} />
              <Route path="/admin/teachers" element={<AdminTeachersPage user={currentUser} />} />
              <Route path="/admin/teachers/:id" element={<TeacherDetailsPage />} />
              <Route path="/admin/secretaries" element={<AdminSecretariesPage user={currentUser} />} />
              <Route path="/admin/secretaries/:id" element={<SecretaryDetailsPage />} />
              <Route path="/admin/parents" element={<AdminParentsPage user={currentUser} />} />
              <Route path="/admin/students" element={<AdminStudentsPage user={currentUser} />} />
              <Route path="/admin/courses" element={<AdminCoursesPage user={currentUser} />} />
              <Route path="/admin/formations" element={<AdminFormationsPage user={currentUser} />} />
              <Route path="/admin/finance" element={<AdminFinancePage user={currentUser} />} />
              <Route path="/admin/settings" element={<AdminSettingsPage user={currentUser} />} />
            </>
          )}

          {/* Teacher Routes */}
          {currentUser.role === Role.TEACHER && (
            <>
              <Route path="/teacher/students" element={<TeacherStudentsPage user={currentUser} />} />
              <Route path="/teacher/classes" element={<TeacherClassesPage user={currentUser} />} />
              <Route path="/teacher/attendance" element={<TeacherAttendancePage />} />
              <Route path="/teacher/exams" element={<TeacherExamsPage />} />
              <Route path="/teacher/extra-activities" element={<TeacherExtraActivitiesPage />} />
            </>
          )}

          {/* Student Routes */}
          {currentUser.role === Role.STUDENT && (
            <>
              <Route path="/student/courses" element={<StudentCoursesPage user={currentUser} />} />
              <Route path="/student/billing" element={<StudentBillingPage user={currentUser} />} />
            </>
          )}

          {/* Secretary Routes */}
          {currentUser.role === Role.SECRETARY && (
            <>
                <Route path="/secretary/students" element={<SecretaryStudentsPage user={currentUser} />} />
                <Route path="/secretary/classes" element={<SecretaryClassesPage user={currentUser} />} />
                <Route path="/secretary/formations" element={<SecretaryFormationsPage user={currentUser} />} />
                <Route path="/secretary/attendance" element={<SecretaryAttendancePage />} />
                <Route path="/secretary/materials" element={<SecretaryMaterialsPage />} />
            </>
          )}

          {/* Parent Routes */}
          {currentUser.role === Role.PARENT && (
            <>
                <Route path="/parent/children" element={<MyChildrenPage user={currentUser} />} />
            </>
          )}

          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </DashboardLayout>
    </HashRouter>
  );
};

const App: React.FC = () => (
  <DataProvider>
    <AppContent />
  </DataProvider>
);

export default App;
