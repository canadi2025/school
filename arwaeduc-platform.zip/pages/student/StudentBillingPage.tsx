import React from 'react';
import { useData } from '../../context/DataContext';
import { PaymentStatus, User } from '../../types';
import PageHeader from '../../components/PageHeader';

const statusColorMap: { [key in PaymentStatus]: string } = {
  [PaymentStatus.COMPLETED]: 'bg-green-100 text-green-800',
  [PaymentStatus.PENDING]: 'bg-yellow-100 text-yellow-800',
  [PaymentStatus.FAILED]: 'bg-red-100 text-red-800',
};

interface StudentBillingPageProps {
    user: User;
}

const StudentBillingPage: React.FC<StudentBillingPageProps> = ({ user: currentStudent }) => {
    const { payments } = useData();
    const studentPayments = payments.filter(p => p.userId === currentStudent.id);

    return (
        <div>
            <PageHeader title="Billing & Payments" buttonLabel="Make a Payment" onButtonClick={() => alert('Make a payment')} />
            <div className="bg-white shadow-md rounded-lg overflow-hidden">
                <table className="min-w-full leading-normal">
                    <thead>
                        <tr>
                            <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Date
                            </th>
                            <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Amount
                            </th>
                            <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Status
                            </th>
                            <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100"></th>
                        </tr>
                    </thead>
                    <tbody>
                        {studentPayments.map(payment => (
                            <tr key={payment.id} className="hover:bg-gray-50">
                                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                                    <p className="text-gray-900 whitespace-no-wrap">{new Date(payment.createdAt).toLocaleDateString()}</p>
                                </td>
                                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                                    <p className="text-gray-900 whitespace-no-wrap font-semibold">${payment.amount.toFixed(2)}</p>
                                </td>
                                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                                    <span className={`relative inline-block px-3 py-1 font-semibold leading-tight rounded-full ${statusColorMap[payment.status]}`}>
                                        <span className="relative">{payment.status}</span>
                                    </span>
                                </td>
                                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm text-right">
                                    <button className="text-primary-600 hover:text-primary-900">View Invoice</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default StudentBillingPage;