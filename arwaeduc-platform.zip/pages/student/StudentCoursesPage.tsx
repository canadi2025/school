import React from 'react';
import { useData } from '../../context/DataContext';
import { User } from '../../types';
import PageHeader from '../../components/PageHeader';

interface StudentCoursesPageProps {
    user: User;
}

const StudentCoursesPage: React.FC<StudentCoursesPageProps> = ({ user: currentStudent }) => {
    const { courses, users } = useData();
    const enrolledCourses = courses.filter(c => c.studentIds.includes(currentStudent.id));
    
    const getTeacherName = (teacherId: number) => {
        const teacher = users.find(u => u.id === teacherId);
        return teacher ? `${teacher.profile.firstName} ${teacher.profile.lastName}` : 'N/A';
    };

    return (
        <div>
            <PageHeader title="My Enrolled Courses" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {enrolledCourses.map(course => (
                    <div key={course.id} className="bg-white rounded-lg shadow-md p-6">
                        <h2 className="text-xl font-bold text-gray-800">{course.title}</h2>
                        <p className="text-gray-600 mt-2">{course.description}</p>
                        <div className="mt-4 pt-4 border-t border-gray-200">
                           <p className="text-sm text-gray-700"><strong>Teacher:</strong> {getTeacherName(course.teacherId)}</p>
                           <p className="text-sm text-gray-500 mt-1"><strong>Schedule:</strong> {course.schedule.length > 0 ? new Date(course.schedule[0]).toLocaleString() : 'Not scheduled'}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default StudentCoursesPage;