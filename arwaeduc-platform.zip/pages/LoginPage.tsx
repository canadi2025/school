import React from 'react';
import { Role } from '../types';
import { SchoolIcon } from '../components/icons/IconComponents';

interface LoginPageProps {
  onLogin: (role: Role) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col justify-center items-center">
      <div className="w-full max-w-md bg-white p-8 rounded-xl shadow-lg">
        <div className="flex flex-col items-center mb-6">
          <div className="bg-primary-100 p-3 rounded-full">
            <SchoolIcon className="h-10 w-10 text-primary-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mt-4">Welcome to EduSaaS</h1>
          <p className="text-gray-500 mt-1">Select a role to view the platform</p>
        </div>
        
        <div className="space-y-4">
          <button
            onClick={() => onLogin(Role.SUPER_ADMIN)}
            className="w-full px-4 py-3 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-red-500"
          >
            Login as Super Admin
          </button>
          <button
            onClick={() => onLogin(Role.ADMIN)}
            className="w-full px-4 py-3 bg-primary-600 text-white font-semibold rounded-lg hover:bg-primary-700 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
          >
            Login as Admin
          </button>
          <button
            onClick={() => onLogin(Role.SECRETARY)}
            className="w-full px-4 py-3 bg-yellow-600 text-white font-semibold rounded-lg hover:bg-yellow-700 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-yellow-500"
          >
            Login as Secretary
          </button>
          <button
            onClick={() => onLogin(Role.TEACHER)}
            className="w-full px-4 py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            Login as Teacher
          </button>
          <button
            onClick={() => onLogin(Role.STUDENT)}
            className="w-full px-4 py-3 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-teal-500"
          >
            Login as Student
          </button>
           <button
            onClick={() => onLogin(Role.PARENT)}
            className="w-full px-4 py-3 bg-orange-600 text-white font-semibold rounded-lg hover:bg-orange-700 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-orange-500"
          >
            Login as Parent
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
