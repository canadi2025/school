import React from 'react';
import PageHeader from '../../components/PageHeader';

const TeacherExtraActivitiesPage: React.FC = () => {
    return (
        <div>
            <PageHeader title="Extra Activities" />
            <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold text-gray-800">Manage Extracurricular Activities</h3>
                <p className="text-gray-600 mt-2">
                    This section will allow teachers to manage extracurricular clubs, sports, or activities, and track student involvement.
                </p>
            </div>
        </div>
    );
};

export default TeacherExtraActivitiesPage;