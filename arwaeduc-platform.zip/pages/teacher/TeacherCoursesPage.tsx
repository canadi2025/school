import React from 'react';
import { useData } from '../../context/DataContext';
import { User } from '../../types';
import PageHeader from '../../components/PageHeader';

interface TeacherClassesPageProps {
    user: User;
}

const TeacherClassesPage: React.FC<TeacherClassesPageProps> = ({ user: currentTeacher }) => {
    const { courses } = useData();
    const teacherCourses = courses.filter(c => c.teacherId === currentTeacher.id);

    return (
        <div>
            <PageHeader title="My Classes" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {teacherCourses.map(course => (
                    <div key={course.id} className="bg-white rounded-lg shadow-md p-6">
                        <h2 className="text-xl font-bold text-gray-800">{course.title}</h2>
                        <p className="text-gray-600 mt-2">{course.description}</p>
                        <div className="mt-4 pt-4 border-t border-gray-200">
                           <p className="text-sm text-gray-500">
                                {course.studentIds.length} Student{course.studentIds.length !== 1 ? 's' : ''} Enrolled
                           </p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default TeacherClassesPage;