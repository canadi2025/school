import React from 'react';
import PageHeader from '../../components/PageHeader';
import { useData } from '../../context/DataContext';
import { User } from '../../types';

interface AdminSettingsPageProps {
    user: User;
}

const AdminSettingsPage: React.FC<AdminSettingsPageProps> = ({ user }) => {
    const { schools } = useData();
    const schoolName = schools.find(s => s.id === user.schoolId)?.name || 'your school';

    return (
        <div>
            <PageHeader title="School Settings" />
            <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold text-gray-800">Settings for {schoolName}</h3>
                <p className="text-gray-600 mt-2">
                    This is where school-specific settings, such as branding, notification preferences, and integration options, will be managed in the future.
                </p>
            </div>
        </div>
    );
};

export default AdminSettingsPage;