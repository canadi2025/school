import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import * as api from '../../services/api';
import { useData } from '../../context/DataContext';
import { User, Role, Profile } from '../../types';
import PageHeader from '../../components/PageHeader';
import AddUserModal from '../../components/modals/AddUserModal';

interface AdminTeachersPageProps {
  user: User;
}

type UserData = {
    firstName: string;
    lastName: string;
    email: string;
    role: Role;
    schoolId?: number;
    profile: Omit<Profile, 'id' | 'userId' | 'firstName' | 'lastName'>;
};

const AdminTeachersPage: React.FC<AdminTeachersPageProps> = ({ user: currentUser }) => {
  const { users, refetchAll } = useData();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const navigate = useNavigate();

  const schoolTeachers = users.filter(u => u.schoolId === currentUser.schoolId && u.role === Role.TEACHER);

  const handleAddUser = async (userData: UserData) => {
    await api.createUser({ ...userData, schoolId: currentUser.schoolId });
    refetchAll();
    setIsAddModalOpen(false);
  };

  return (
    <div>
      <PageHeader title="Manage Teachers" buttonLabel="Add Teacher" onButtonClick={() => setIsAddModalOpen(true)} />
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <table className="min-w-full leading-normal">
          <thead>
            <tr>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Name
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Email
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Created At
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100"></th>
            </tr>
          </thead>
          <tbody>
            {schoolTeachers.map((teacher) => (
              <tr key={teacher.id} className="hover:bg-gray-50">
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap">{teacher.profile.firstName} {teacher.profile.lastName}</p>
                </td>
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap">{teacher.email}</p>
                </td>
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap">{new Date(teacher.createdAt).toLocaleDateString()}</p>
                </td>
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm text-right">
                  <button onClick={() => navigate(`/admin/teachers/${teacher.id}`)} className="text-indigo-600 hover:text-indigo-900 font-medium">View Details</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

       {isAddModalOpen && (
        <AddUserModal
          onClose={() => setIsAddModalOpen(false)}
          onAddUser={handleAddUser}
          currentUser={currentUser}
          defaultRole={Role.TEACHER}
        />
      )}
    </div>
  );
};

export default AdminTeachersPage;