import React, { useState } from 'react';
import * as api from '../../services/api';
import { useData } from '../../context/DataContext';
import { User, Role, Profile } from '../../types';
import PageHeader from '../../components/PageHeader';
import AddUserModal from '../../components/modals/AddUserModal';

interface AdminStudentsPageProps {
  user: User;
}

type UserData = {
    firstName: string;
    lastName: string;
    email: string;
    role: Role;
    schoolId?: number;
    profile: Omit<Profile, 'id' | 'userId' | 'firstName' | 'lastName'>;
};

const AdminStudentsPage: React.FC<AdminStudentsPageProps> = ({ user: currentUser }) => {
  const { users, refetchAll } = useData();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const schoolStudents = users.filter(u => u.schoolId === currentUser.schoolId && u.role === Role.STUDENT);

  const handleAddUser = async (userData: UserData) => {
    await api.createUser({ ...userData, schoolId: currentUser.schoolId });
    refetchAll();
    setIsAddModalOpen(false);
  };

  return (
    <div>
      <PageHeader title="Manage Students" buttonLabel="Add Student" onButtonClick={() => setIsAddModalOpen(true)} />
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <table className="min-w-full leading-normal">
          <thead>
            <tr>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Name
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Email
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Created At
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100"></th>
            </tr>
          </thead>
          <tbody>
            {schoolStudents.map((student) => (
              <tr key={student.id} className="hover:bg-gray-50">
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap">{student.profile.firstName} {student.profile.lastName}</p>
                </td>
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap">{student.email}</p>
                </td>
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap">{new Date(student.createdAt).toLocaleDateString()}</p>
                </td>
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm text-right">
                  <button className="text-indigo-600 hover:text-indigo-900">Edit</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {isAddModalOpen && (
        <AddUserModal
          onClose={() => setIsAddModalOpen(false)}
          onAddUser={handleAddUser}
          currentUser={currentUser}
          defaultRole={Role.STUDENT}
        />
      )}
    </div>
  );
};

export default AdminStudentsPage;