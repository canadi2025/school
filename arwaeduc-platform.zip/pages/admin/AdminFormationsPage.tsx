import React, { useState, useMemo } from 'react';
import * as api from '../../services/api';
import { useData } from '../../context/DataContext';
import { Course, User, Role, FormationCategory } from '../../types';
import PageHeader from '../../components/PageHeader';
import AddCourseModal from '../../components/modals/AddCourseModal';
import { useSchoolPermissions } from '../../hooks/useSchoolPermissions';

interface AdminFormationsPageProps {
  user: User;
}

const categoryColors: Record<FormationCategory, string> = {
    [FormationCategory.SCOLAIRE_SOUTIEN]: 'bg-blue-100 text-blue-800',
    [FormationCategory.TRAINING]: 'bg-purple-100 text-purple-800',
    [FormationCategory.LANGUES]: 'bg-green-100 text-green-800',
    [FormationCategory.OTHERS]: 'bg-gray-100 text-gray-800',
};

const AdminFormationsPage: React.FC<AdminFormationsPageProps> = ({ user }) => {
  const { courses, schools, users, refetchAll } = useData();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const { permissions } = useSchoolPermissions(user.schoolId);

  // Filter for items that ARE formations (i.e., have a category)
  const formations = courses.filter(c => !!c.category);

  const formationsToShow = user.role === Role.SUPER_ADMIN 
    ? formations 
    : formations.filter(c => c.schoolId === user.schoolId);

  const schoolMap = useMemo(() => schools.reduce((acc, school) => {
    acc[school.id] = school.name;
    return acc;
  }, {} as Record<number, string>), [schools]);

  const userMap = useMemo(() => users.reduce((acc, user) => {
    acc[user.id] = `${user.profile.firstName} ${user.profile.lastName}`;
    return acc;
  }, {} as Record<number, string>), [users]);

  const handleAddFormation = async (formationData: Omit<Course, 'id' | 'studentIds'>) => {
    await api.createCourse(formationData);
    refetchAll();
    setIsAddModalOpen(false);
  };
  
  const handleDeleteFormation = async (formationId: number) => {
    if (window.confirm('Are you sure you want to delete this formation?')) {
      await api.deleteCourse(formationId);
      refetchAll();
    }
  };

  const canAddCourse = user.role === Role.SUPER_ADMIN || permissions.canAddCourse;

  return (
    <div>
      <PageHeader title="Manage Formations" buttonLabel="Add New Formation" onButtonClick={() => setIsAddModalOpen(true)} />
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <table className="min-w-full leading-normal">
          <thead>
            <tr>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Formation Title
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Category
              </th>
               <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Teacher
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Enrolled
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100"></th>
            </tr>
          </thead>
          <tbody>
            {formationsToShow.map((formation) => (
              <tr key={formation.id} className="hover:bg-gray-50">
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap font-semibold">{formation.title}</p>
                  {formation.details && <p className="text-gray-500 whitespace-no-wrap text-xs mt-1">{formation.details}</p>}
                </td>
                 <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                   <span className={`px-2 py-1 text-xs font-semibold rounded-full ${categoryColors[formation.category!]}`}>
                     {formation.category}
                   </span>
                </td>
                 <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap">{userMap[formation.teacherId] || 'N/A'}</p>
                </td>
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap">{formation.studentIds.length}</p>
                </td>
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm text-right whitespace-no-wrap">
                   <button 
                    onClick={() => handleDeleteFormation(formation.id)}
                    className="text-red-600 hover:text-red-900 font-medium"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isAddModalOpen && (
        <AddCourseModal
          onClose={() => setIsAddModalOpen(false)}
          onAddCourse={handleAddFormation}
          schools={schools}
          users={users}
          user={user}
          context="formation"
        />
      )}
    </div>
  );
};

export default AdminFormationsPage;