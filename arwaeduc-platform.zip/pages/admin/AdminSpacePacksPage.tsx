import React, { useState } from 'react';
import * as api from '../../services/api';
import { useData } from '../../context/DataContext';
import { SpacePackLimits, SubscriptionPack } from '../../types';
import PageHeader from '../../components/PageHeader';
import EditSpacePackModal from '../../components/modals/EditSpacePackModal';
import { UsersIcon, CoursesIcon, SchoolIcon, CheckCircleIcon, XCircleIcon } from '../../components/icons/IconComponents';

const packColors: Record<SubscriptionPack, string> = {
  [SubscriptionPack.SIMPLE]: 'border-blue-500',
  [SubscriptionPack.STARTER]: 'border-purple-500',
  [SubscriptionPack.BUSINESS]: 'border-green-500',
};

const LimitDisplay: React.FC<{ icon: React.FC<{className?: string}>, label: string, value: number }> = ({ icon: Icon, label, value }) => (
    <div className="flex items-center text-gray-700">
        <Icon className="w-5 h-5 mr-3 text-gray-400" />
        <span className="font-medium">{label}:</span>
        <span className="ml-auto font-semibold text-lg">{isFinite(value) ? value : 'Unlimited'}</span>
    </div>
);

const FeatureDisplay: React.FC<{ label: string, enabled: boolean }> = ({ label, enabled }) => (
    <div className="flex items-center text-gray-700">
        {enabled ? <CheckCircleIcon className="w-5 h-5 mr-3 text-green-500" /> : <XCircleIcon className="w-5 h-5 mr-3 text-red-500" />}
        <span className={`font-medium ${enabled ? 'text-gray-700' : 'text-gray-400 line-through'}`}>{label}</span>
    </div>
);

const AdminSpacePacksPage: React.FC = () => {
  const { spacePacks, refetchAll } = useData();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedPack, setSelectedPack] = useState<SubscriptionPack | null>(null);

  const handleUpdateLimits = async (pack: SubscriptionPack, limits: SpacePackLimits) => {
    await api.updateSpacePack(pack, limits);
    refetchAll();
    setIsModalOpen(false);
  };

  const handleEditClick = (pack: SubscriptionPack) => {
    setSelectedPack(pack);
    setIsModalOpen(true);
  };

  if (!spacePacks) {
    return <div>Loading space packs...</div>;
  }

  return (
    <div>
      <PageHeader title="Manage Space Packs" />
      <p className="text-gray-600 mb-8 -mt-4">Define the resource limits and features for each subscription tier.</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {Object.entries(spacePacks).map(([pack, limits]) => (
          <div key={pack} className={`bg-white rounded-lg shadow-md border-t-4 ${packColors[pack as SubscriptionPack]} flex flex-col`}>
            <div className="p-6 flex-grow">
                <h2 className="text-2xl font-bold text-gray-800 capitalize">{pack.toLowerCase()} Pack</h2>
                <p className="text-gray-500 text-sm mb-6">Resource allocation & features</p>
                
                <h3 className="font-semibold text-gray-600 text-sm mb-2 border-b pb-1">Resource Limits</h3>
                <div className="space-y-3 mb-6">
                    <LimitDisplay icon={UsersIcon} label="Max Students" value={limits.maxStudents} />
                    <LimitDisplay icon={CoursesIcon} label="Max Courses" value={limits.maxCourses} />
                    <LimitDisplay icon={SchoolIcon} label="Max Teachers" value={limits.maxTeachers} />
                    <LimitDisplay icon={UsersIcon} label="Max Secretaries" value={limits.maxSecretaries} />
                </div>

                <h3 className="font-semibold text-gray-600 text-sm mb-2 border-b pb-1">Dashboards</h3>
                <div className="space-y-3 mb-6">
                    <FeatureDisplay label="Admin Dashboard" enabled={limits.adminDashboard} />
                    <FeatureDisplay label="Parent Dashboard" enabled={limits.parentDashboard} />
                </div>

                {limits.features.length > 0 && (
                    <>
                        <h3 className="font-semibold text-gray-600 text-sm mb-2 border-b pb-1">Additional Features</h3>
                        <ul className="space-y-3">
                           {limits.features.map(feature => (
                               <li key={feature} className="flex items-center text-gray-700">
                                   <CheckCircleIcon className="w-5 h-5 mr-3 text-green-500" />
                                   <span className="font-medium">{feature}</span>
                               </li>
                           ))}
                        </ul>
                    </>
                )}
            </div>
            <div className="px-6 py-4 bg-gray-50 rounded-b-lg mt-auto">
                 <button
                    onClick={() => handleEditClick(pack as SubscriptionPack)}
                    className="w-full px-4 py-2 bg-primary-600 text-white font-semibold rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-opacity-50 transition-colors"
                    >
                    Edit Pack
                </button>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && selectedPack && (
        <EditSpacePackModal
          pack={selectedPack}
          limits={spacePacks[selectedPack]}
          onClose={() => setIsModalOpen(false)}
          onUpdate={handleUpdateLimits}
        />
      )}
    </div>
  );
};

export default AdminSpacePacksPage;