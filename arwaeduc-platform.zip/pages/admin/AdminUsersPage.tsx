import React, { useState, useMemo } from 'react';
import * as api from '../../services/api';
import { useData } from '../../context/DataContext';
import { User, Role, Profile } from '../../types';
import PageHeader from '../../components/PageHeader';
import AddUserModal from '../../components/modals/AddUserModal';

interface AdminUsersPageProps {
  user: User;
}

type UserData = {
    firstName: string;
    lastName: string;
    email: string;
    role: Role;
    schoolId?: number;
    profile: Omit<Profile, 'id' | 'userId' | 'firstName' | 'lastName'>;
};

const AdminUsersPage: React.FC<AdminUsersPageProps> = ({ user: currentUser }) => {
  const { users, schools, refetchAll } = useData();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  
  const usersToShow = currentUser.role === Role.SUPER_ADMIN
    ? users
    : users.filter(u => u.schoolId === currentUser.schoolId);

  const schoolMap = useMemo(() => schools.reduce((acc, school) => {
    acc[school.id] = school.name;
    return acc;
  }, {} as Record<number, string>), [schools]);

  const handleAddUser = async (userData: UserData) => {
    await api.createUser(userData);
    refetchAll();
    setIsAddModalOpen(false);
  };
  
  const handleDeleteUser = async (userId: number) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      await api.deleteUser(userId);
      refetchAll();
    }
  };

  return (
    <div>
       <PageHeader 
          title="All School Users" 
          buttonLabel="Add New User" 
          onButtonClick={() => setIsAddModalOpen(true)} 
        />
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <table className="min-w-full leading-normal">
          <thead>
            <tr>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Name</th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Role</th>
              {currentUser.role === Role.SUPER_ADMIN && (
                <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">School</th>
              )}
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Created At</th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100"></th>
            </tr>
          </thead>
          <tbody>
            {usersToShow.map((user) => (
              <tr key={user.id} className="hover:bg-gray-50">
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap font-semibold">{user.profile.firstName} {user.profile.lastName}</p>
                  <p className="text-gray-600 whitespace-no-wrap text-xs">{user.email}</p>
                </td>
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                  <span className="relative inline-block px-3 py-1 font-semibold text-green-900 leading-tight">
                    <span aria-hidden className="absolute inset-0 bg-green-200 opacity-50 rounded-full"></span>
                    <span className="relative">{user.role}</span>
                  </span>
                </td>
                {currentUser.role === Role.SUPER_ADMIN && (
                   <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                    <p className="text-gray-900 whitespace-no-wrap">{user.schoolId ? schoolMap[user.schoolId] : 'N/A'}</p>
                  </td>
                )}
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap">{new Date(user.createdAt).toLocaleDateString()}</p>
                </td>
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm text-right">
                  <button onClick={() => handleDeleteUser(user.id)} className="text-red-600 hover:text-red-900 font-medium">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {isAddModalOpen && (
        <AddUserModal
          onClose={() => setIsAddModalOpen(false)}
          onAddUser={handleAddUser}
          schools={schools}
          currentUser={currentUser}
        />
      )}
    </div>
  );
};
export default AdminUsersPage;
