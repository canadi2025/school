import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useData } from '../../context/DataContext';
import PageHeader from '../../components/PageHeader';
import { PhoneIcon, MapPinIcon, LinkIcon, DocumentTextIcon, CoursesIcon } from '../../components/icons/IconComponents';

const DetailItem: React.FC<{ icon: React.FC<{className?: string}>, label: string, value?: string }> = ({ icon: Icon, label, value }) => {
    if (!value) return null;
    return (
        <div className="flex items-start text-sm">
            <Icon className="w-4 h-4 mr-3 mt-0.5 text-gray-400 flex-shrink-0" />
            <div>
                <span className="font-semibold text-gray-600">{label}:</span>
                <span className="ml-2 text-gray-800">{value}</span>
            </div>
        </div>
    );
};

const TeacherDetailsPage: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const { users, courses } = useData();
    const teacherId = parseInt(id || '0', 10);
    
    const teacher = users.find(u => u.id === teacherId);
    const assignedCourses = courses.filter(c => c.teacherId === teacherId);

    if (!teacher) {
        return (
            <div>
                <PageHeader title="Teacher Not Found" />
                <p>The requested teacher could not be found.</p>
                 <button onClick={() => navigate(-1)} className="mt-4 text-primary-600 hover:underline">
                    &larr; Back to Teachers
                </button>
            </div>
        );
    }

    return (
        <div>
            <div className="mb-6">
                <button onClick={() => navigate(-1)} className="flex items-center text-sm text-gray-500 hover:text-gray-700">
                     <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"></path></svg>
                    Back to Teachers
                </button>
            </div>
            
            <div className="flex items-center space-x-4 mb-8">
                 <div className="w-20 h-20 rounded-full bg-indigo-500 text-white flex items-center justify-center font-bold text-3xl flex-shrink-0">
                    {teacher.profile.firstName.charAt(0)}{teacher.profile.lastName.charAt(0)}
                </div>
                <div>
                    <h1 className="text-3xl font-bold text-gray-800">{teacher.profile.firstName} {teacher.profile.lastName}</h1>
                    <p className="text-gray-500">{teacher.email}</p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1 space-y-6">
                    {/* Contact Info Card */}
                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <h3 className="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">Contact Information</h3>
                        <div className="space-y-3">
                            <DetailItem icon={PhoneIcon} label="Phone" value={teacher.profile.phone} />
                            <DetailItem icon={MapPinIcon} label="Address" value={teacher.profile.address} />
                            <DetailItem icon={LinkIcon} label="Social" value={teacher.profile.socialMediaLink} />
                        </div>
                    </div>
                     {/* Documents Card */}
                     {teacher.profile.documents && teacher.profile.documents.length > 0 && (
                        <div className="bg-white p-6 rounded-lg shadow-md">
                            <h3 className="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">Documents</h3>
                            <ul className="space-y-2">
                                {teacher.profile.documents.map((doc, index) => (
                                    <li key={index} className="flex items-center text-sm text-primary-700 hover:underline cursor-pointer">
                                        <DocumentTextIcon className="w-4 h-4 mr-2" />
                                        {doc}
                                    </li>
                                ))}
                            </ul>
                        </div>
                     )}
                </div>

                <div className="lg:col-span-2">
                    {/* Assigned Courses Card */}
                     <div className="bg-white p-6 rounded-lg shadow-md">
                        <h3 className="text-lg font-semibold text-gray-800 border-b pb-2 mb-4 flex items-center">
                            <CoursesIcon className="w-5 h-5 mr-2 text-gray-400" />
                            Assigned Courses ({assignedCourses.length})
                        </h3>
                        {assignedCourses.length > 0 ? (
                            <ul className="space-y-3">
                                {assignedCourses.map(course => (
                                    <li key={course.id} className="p-3 bg-gray-50 rounded-md">
                                        <p className="font-semibold text-gray-800">{course.title}</p>
                                        <p className="text-sm text-gray-600">{course.studentIds.length} student(s) enrolled</p>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                             <p className="text-gray-500 text-sm">This teacher is not assigned to any courses.</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TeacherDetailsPage;