import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import * as api from '../../services/api';
import { useData } from '../../context/DataContext';
import { User, Role, Profile } from '../../types';
import PageHeader from '../../components/PageHeader';
import AddUserModal from '../../components/modals/AddUserModal';

interface AdminSecretariesPageProps {
  user: User;
}

type UserData = {
    firstName: string;
    lastName: string;
    email: string;
    role: Role;
    schoolId?: number;
    profile: Omit<Profile, 'id' | 'userId' | 'firstName' | 'lastName'>;
};

const AdminSecretariesPage: React.FC<AdminSecretariesPageProps> = ({ user: currentUser }) => {
  const { users, refetchAll } = useData();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const navigate = useNavigate();

  const schoolSecretaries = users.filter(u => u.schoolId === currentUser.schoolId && u.role === Role.SECRETARY);

  const handleAddUser = async (userData: UserData) => {
    await api.createUser({ ...userData, schoolId: currentUser.schoolId });
    refetchAll();
    setIsAddModalOpen(false);
  };

  return (
    <div>
      <PageHeader title="Manage Secretaries" buttonLabel="Add Secretary" onButtonClick={() => setIsAddModalOpen(true)} />
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <table className="min-w-full leading-normal">
          <thead>
            <tr>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Name
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Email
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Created At
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100"></th>
            </tr>
          </thead>
          <tbody>
            {schoolSecretaries.map((secretary) => (
              <tr key={secretary.id} className="hover:bg-gray-50">
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap">{secretary.profile.firstName} {secretary.profile.lastName}</p>
                </td>
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap">{secretary.email}</p>
                </td>
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap">{new Date(secretary.createdAt).toLocaleDateString()}</p>
                </td>
                <td className="px-5 py-5 border-b border-gray-200 bg-white text-sm text-right">
                  <button onClick={() => navigate(`/admin/secretaries/${secretary.id}`)} className="text-indigo-600 hover:text-indigo-900 font-medium">View Details</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
       {isAddModalOpen && (
        <AddUserModal
          onClose={() => setIsAddModalOpen(false)}
          onAddUser={handleAddUser}
          currentUser={currentUser}
          defaultRole={Role.SECRETARY}
        />
      )}
    </div>
  );
};

export default AdminSecretariesPage;