import React from 'react';
import { useData } from '../../context/DataContext';
import { PaymentStatus, User, Role } from '../../types';
import PageHeader from '../../components/PageHeader';

const statusColorMap: { [key in PaymentStatus]: string } = {
  [PaymentStatus.COMPLETED]: 'bg-green-100 text-green-800',
  [PaymentStatus.PENDING]: 'bg-yellow-100 text-yellow-800',
  [PaymentStatus.FAILED]: 'bg-red-100 text-red-800',
};

interface AdminPaymentsPageProps {
  user: User;
}

const AdminPaymentsPage: React.FC<AdminPaymentsPageProps> = ({ user }) => {
  const { payments, users } = useData();

  const schoolUserIds = user.role === Role.ADMIN 
    ? users.filter(u => u.schoolId === user.schoolId).map(u => u.id)
    : [];
    
  const paymentsToShow = user.role === Role.SUPER_ADMIN
    ? payments
    : payments.filter(p => schoolUserIds.includes(p.userId));

  const getUserName = (userId: number) => {
    const user = users.find(u => u.id === userId);
    return user ? `${user.profile.firstName} ${user.profile.lastName}` : 'Unknown User';
  };

  return (
    <div>
      <PageHeader title="Payment History" />
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <table className="min-w-full leading-normal">
          <thead>
            <tr>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                User
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Amount
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Date
              </th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Status
              </th>
            </tr>
          </thead>
          <tbody>
            {paymentsToShow.map((payment) => (
              <tr key={payment.id} className="hover:bg-gray-50">
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap">{getUserName(payment.userId)}</p>
                </td>
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap font-semibold">${payment.amount.toFixed(2)} {payment.currency}</p>
                </td>
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap">{new Date(payment.createdAt).toLocaleDateString()}</p>
                </td>
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                  <span className={`relative inline-block px-3 py-1 font-semibold leading-tight rounded-full ${statusColorMap[payment.status]}`}>
                    <span className="relative">{payment.status}</span>
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminPaymentsPage;