import React, { useState, useMemo } from 'react';
import * as api from '../../services/api';
import { useData } from '../../context/DataContext';
import { Course, User, Role } from '../../types';
import PageHeader from '../../components/PageHeader';
import AddCourseModal from '../../components/modals/AddCourseModal';
import { useSchoolPermissions } from '../../hooks/useSchoolPermissions';

interface AdminCoursesPageProps {
  user: User;
}

const PageHeaderWithTooltip: React.FC<{ title: string; buttonLabel: string; onButtonClick: () => void; disabled: boolean; tooltip: string }> = ({ title, buttonLabel, onButtonClick, disabled, tooltip }) => (
  <div className="flex justify-between items-center mb-6">
    <h1 className="text-2xl font-semibold text-gray-800">{title}</h1>
    <div className="relative group">
      <button
        onClick={onButtonClick}
        disabled={disabled}
        className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-opacity-50 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
      >
        {buttonLabel}
      </button>
      {disabled && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-max px-2 py-1 bg-gray-800 text-white text-xs rounded-md opacity-0 group-hover:opacity-90 transition-opacity duration-200">
          {tooltip}
        </div>
      )}
    </div>
  </div>
);


const AdminCoursesPage: React.FC<AdminCoursesPageProps> = ({ user }) => {
  const { courses, schools, users, refetchAll } = useData();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const { permissions } = useSchoolPermissions(user.schoolId);
  
  const regularCourses = courses.filter(c => !c.category);

  const coursesToShow = user.role === Role.SUPER_ADMIN 
    ? regularCourses 
    : regularCourses.filter(c => c.schoolId === user.schoolId);

  const schoolMap = useMemo(() => schools.reduce((acc, school) => {
    acc[school.id] = school.name;
    return acc;
  }, {} as Record<number, string>), [schools]);

  const userMap = useMemo(() => users.reduce((acc, user) => {
    acc[user.id] = `${user.profile.firstName} ${user.profile.lastName}`;
    return acc;
  }, {} as Record<number, string>), [users]);

  const handleAddCourse = async (courseData: Omit<Course, 'id' | 'studentIds'>) => {
    await api.createCourse(courseData);
    refetchAll();
    setIsAddModalOpen(false);
  };
  
  const handleDeleteCourse = async (courseId: number) => {
    if (window.confirm('Are you sure you want to delete this course? This action cannot be undone.')) {
      await api.deleteCourse(courseId);
      refetchAll();
    }
  };

  const canAddCourse = user.role === Role.SUPER_ADMIN || permissions.canAddCourse;

  return (
    <div>
      {user.role === Role.ADMIN ? (
        <PageHeaderWithTooltip
          title="Manage Courses"
          buttonLabel="Add New Course"
          onButtonClick={() => setIsAddModalOpen(true)}
          disabled={!canAddCourse}
          tooltip="Course limit reached for your plan."
        />
      ) : (
        <PageHeader title="Manage Courses" buttonLabel="Add New Course" onButtonClick={() => setIsAddModalOpen(true)} />
      )}
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <table className="min-w-full leading-normal">
          <thead>
            <tr>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Course Title</th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">School</th>
               <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Teacher</th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Enrolled Students</th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100"></th>
            </tr>
          </thead>
          <tbody>
            {coursesToShow.map((course) => (
              <tr key={course.id} className="hover:bg-gray-50">
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm"><p className="text-gray-900 whitespace-no-wrap font-semibold">{course.title}</p></td>
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm"><p className="text-gray-600 whitespace-no-wrap">{schoolMap[course.schoolId] || 'N/A'}</p></td>
                 <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm"><p className="text-gray-900 whitespace-no-wrap">{userMap[course.teacherId] || 'N/A'}</p></td>
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm"><p className="text-gray-900 whitespace-no-wrap">{course.studentIds.length}</p></td>
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm text-right whitespace-no-wrap">
                  <button className="text-primary-600 hover:text-primary-900 font-medium mr-4">Details</button>
                   <button onClick={() => handleDeleteCourse(course.id)} className="text-red-600 hover:text-red-900 font-medium">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isAddModalOpen && (
        <AddCourseModal
          onClose={() => setIsAddModalOpen(false)}
          onAddCourse={handleAddCourse}
          schools={schools}
          users={users}
          user={user}
          context="course"
        />
      )}
    </div>
  );
};

export default AdminCoursesPage;
