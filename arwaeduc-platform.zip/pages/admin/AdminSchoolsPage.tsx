import React, { useState, useMemo } from 'react';
import * as api from '../../services/api';
import { useData } from '../../context/DataContext';
import { School, User, Role, SubscriptionPack, SubscriptionStatus } from '../../types';
import PageHeader from '../../components/PageHeader';
import AddSchoolModal from '../../components/modals/AddSchoolModal';
import EditSchoolModal from '../../components/modals/EditSchoolModal';
import EnrollStudentModal from '../../components/modals/EnrollStudentModal';
import ManageSubscriptionModal from '../../components/modals/ManageSubscriptionModal';

interface AdminSchoolsPageProps {
  user: User;
}

const statusColorMap: { [key in SubscriptionStatus]: string } = {
  [SubscriptionStatus.ACTIVE]: 'bg-green-100 text-green-800',
  [SubscriptionStatus.PENDING]: 'bg-yellow-100 text-yellow-800',
  [SubscriptionStatus.CANCELED]: 'bg-red-100 text-red-800',
};

const AdminSchoolsPage: React.FC<AdminSchoolsPageProps> = ({ user }) => {
  const { schools, courses, users, refetchAll } = useData();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isEnrollModalOpen, setIsEnrollModalOpen] = useState(false);
  const [isManageSubModalOpen, setIsManageSubModalOpen] = useState(false);
  const [selectedSchool, setSelectedSchool] = useState<School | null>(null);

  const userCountBySchool = useMemo(() => {
    return users.reduce((acc, user) => {
      if (user.schoolId) {
        acc[user.schoolId] = (acc[user.schoolId] || 0) + 1;
      }
      return acc;
    }, {} as Record<number, number>);
  }, [users]);

  const handleAddSchool = async (schoolData: { name: string; address?: string; pack: SubscriptionPack, featureOverrides: School['featureOverrides'] }) => {
    // FIX: Changed `subscriptionPack` to `pack` to match the `CreateSchoolData` type.
    await api.createSchool({ 
        name: schoolData.name, 
        address: schoolData.address, 
        pack: schoolData.pack,
        featureOverrides: schoolData.featureOverrides
    });
    refetchAll();
    setIsAddModalOpen(false);
  };

  const handleUpdateSchool = async (schoolId: number, schoolData: { name:string; address?: string }) => {
    await api.updateSchool(schoolId, schoolData);
    refetchAll();
    setIsEditModalOpen(false);
    setSelectedSchool(null);
  };
  
  const handleEnrollStudent = async (courseId: number, studentId: number) => {
    await api.enrollStudent(courseId, studentId);
    refetchAll();
    setIsEnrollModalOpen(false);
    setSelectedSchool(null);
  };

  const handleUpdateSubscription = async (schoolId: number, pack: SubscriptionPack, status: SubscriptionStatus, featureOverrides: School['featureOverrides']) => {
    await api.updateSubscription(schoolId, pack, status, featureOverrides);
    refetchAll();
    setIsManageSubModalOpen(false);
    setSelectedSchool(null);
  };

  const handleEditClick = (school: School) => { setSelectedSchool(school); setIsEditModalOpen(true); };
  const handleEnrollClick = (school: School) => { setSelectedSchool(school); setIsEnrollModalOpen(true); };
  const handleManageSubClick = (school: School) => { setSelectedSchool(school); setIsManageSubModalOpen(true); }

  return (
    <div>
      <PageHeader title="Manage Schools" buttonLabel="Add New School" onButtonClick={() => setIsAddModalOpen(true)} />
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <table className="min-w-full leading-normal">
          <thead>
            <tr>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">School Name</th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Subscription Pack</th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Users</th>
              <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100"></th>
            </tr>
          </thead>
          <tbody>
            {schools.map((school) => (
              <tr key={school.id} className="hover:bg-gray-50">
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                  <p className="text-gray-900 whitespace-no-wrap font-semibold">{school.name}</p>
                   <p className="text-gray-600 whitespace-no-wrap text-xs">{school.address || 'N/A'}</p>
                </td>
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm"><p className="text-gray-800 whitespace-no-wrap">{school.subscriptionPack}</p></td>
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                  <span className={`relative inline-block px-3 py-1 font-semibold leading-tight rounded-full ${statusColorMap[school.subscriptionStatus]}`}>
                    <span className="relative">{school.subscriptionStatus}</span>
                  </span>
                </td>
                 <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm"><p className="text-gray-900 whitespace-no-wrap">{userCountBySchool[school.id] || 0}</p></td>
                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm text-right whitespace-no-wrap">
                   <button onClick={() => handleEnrollClick(school)} className="text-indigo-600 hover:text-indigo-900 mr-4 font-medium">Enroll Student</button>
                  {user.role === Role.SUPER_ADMIN && (
                    <>
                      <button onClick={() => handleManageSubClick(school)} className="text-green-600 hover:text-green-900 mr-4 font-medium">Manage</button>
                      <button onClick={() => handleEditClick(school)} className="text-primary-600 hover:text-primary-900 font-medium">Edit</button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isAddModalOpen && <AddSchoolModal onClose={() => setIsAddModalOpen(false)} onAddSchool={handleAddSchool} />}
      {isEditModalOpen && selectedSchool && <EditSchoolModal school={selectedSchool} onClose={() => {setIsEditModalOpen(false); setSelectedSchool(null);}} onUpdateSchool={handleUpdateSchool} />}
      {isEnrollModalOpen && selectedSchool && <EnrollStudentModal school={selectedSchool} allCourses={courses} allUsers={users} onClose={() => {setIsEnrollModalOpen(false); setSelectedSchool(null);}} onEnroll={handleEnrollStudent} />}
      {isManageSubModalOpen && selectedSchool && <ManageSubscriptionModal school={selectedSchool} onClose={() => {setIsManageSubModalOpen(false); setSelectedSchool(null);}} onUpdate={handleUpdateSubscription} />}
    </div>
  );
};

export default AdminSchoolsPage;
