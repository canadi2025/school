import React from 'react';
import { useData } from '../../context/DataContext';
import { User } from '../../types';
import PageHeader from '../../components/PageHeader';

interface MyChildrenPageProps {
    user: User;
}

const MyChildrenPage: React.FC<MyChildrenPageProps> = ({ user }) => {
    const { users, courses } = useData();
    const childIds = user.profile.childIds || [];
    const children = users.filter(u => childIds.includes(u.id));

    const getChildCourses = (childId: number) => {
        return courses.filter(course => course.studentIds.includes(childId));
    };

    return (
        <div>
            <PageHeader title="My Children" />
            {children.length > 0 ? (
                <div className="space-y-6">
                    {children.map(child => (
                        <div key={child.id} className="bg-white rounded-lg shadow-md p-6">
                            <div className="flex items-center mb-4">
                                <div className="w-12 h-12 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center font-bold text-xl flex-shrink-0">
                                    {child.profile.firstName.charAt(0)}{child.profile.lastName.charAt(0)}
                                </div>
                                <div className="ml-4">
                                    <h2 className="text-xl font-bold text-gray-800">{child.profile.firstName} {child.profile.lastName}</h2>
                                    <p className="text-gray-500">{child.email}</p>
                                </div>
                            </div>
                            
                            <div>
                                <h3 className="text-md font-semibold text-gray-700 mb-2">Enrolled Courses</h3>
                                {getChildCourses(child.id).length > 0 ? (
                                    <ul className="space-y-2">
                                        {getChildCourses(child.id).map(course => (
                                            <li key={course.id} className="p-3 bg-gray-50 rounded-md">
                                                <p className="font-semibold text-gray-800">{course.title}</p>
                                                <p className="text-sm text-gray-600">{course.description}</p>
                                            </li>
                                        ))}
                                    </ul>
                                ) : (
                                    <p className="text-gray-500">Not enrolled in any courses.</p>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-10 bg-white rounded-lg shadow-md">
                    <p className="text-gray-600">No children linked to this account.</p>
                </div>
            )}
        </div>
    );
};

export default MyChildrenPage;