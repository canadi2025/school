import React from 'react';
import PageHeader from '../../components/PageHeader';

const SecretaryAttendancePage: React.FC = () => {
    return (
        <div>
            <PageHeader title="Manage Attendance" />
            <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold text-gray-800">Attendance Records</h3>
                <p className="text-gray-600 mt-2">
                    This section will contain tools for secretaries to manage and view attendance records for all classes in the school.
                </p>
            </div>
        </div>
    );
};

export default SecretaryAttendancePage;