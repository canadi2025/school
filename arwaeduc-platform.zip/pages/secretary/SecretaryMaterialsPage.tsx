import React from 'react';
import PageHeader from '../../components/PageHeader';

const SecretaryMaterialsPage: React.FC = () => {
    return (
        <div>
            <PageHeader title="Manage Materials" />
            <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold text-gray-800">School Materials</h3>
                <p className="text-gray-600 mt-2">
                    This section will allow secretaries to upload, organize, and distribute shared school materials and resources.
                </p>
            </div>
        </div>
    );
};

export default SecretaryMaterialsPage;