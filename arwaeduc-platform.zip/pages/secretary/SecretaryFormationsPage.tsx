import React, { useState } from 'react';
import * as api from '../../services/api';
import { useData } from '../../context/DataContext';
import { User, Course, FormationCategory } from '../../types';
import PageHeader from '../../components/PageHeader';
import AddCourseModal from '../../components/modals/AddCourseModal';

interface SecretaryFormationsPageProps {
    user: User;
}

const categoryColors: Record<FormationCategory, string> = {
    [FormationCategory.SCOLAIRE_SOUTIEN]: 'bg-blue-100 text-blue-800',
    [FormationCategory.TRAINING]: 'bg-purple-100 text-purple-800',
    [FormationCategory.LANGUES]: 'bg-green-100 text-green-800',
    [FormationCategory.OTHERS]: 'bg-gray-100 text-gray-800',
};

const SecretaryFormationsPage: React.FC<SecretaryFormationsPageProps> = ({ user }) => {
    const { courses, users, schools, refetchAll } = useData();
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);

    const schoolFormations = courses.filter(c => c.schoolId === user.schoolId && !!c.category);

    const getTeacherName = (teacherId: number) => {
        const teacher = users.find(u => u.id === teacherId);
        return teacher ? `${teacher.profile.firstName} ${teacher.profile.lastName}` : 'N/A';
    };
    
    const handleAddFormation = async (formationData: Omit<Course, 'id' | 'studentIds'>) => {
        await api.createCourse(formationData);
        refetchAll();
        setIsAddModalOpen(false);
    };

    return (
        <div>
            <PageHeader title="School Formations" buttonLabel="Add Formation" onButtonClick={() => setIsAddModalOpen(true)} />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {schoolFormations.map(formation => (
                    <div key={formation.id} className="bg-white rounded-lg shadow-md p-6 flex flex-col">
                        <div>
                             <span className={`text-xs font-semibold mr-2 px-2.5 py-0.5 rounded-full ${categoryColors[formation.category!]}`}>
                                {formation.category}
                            </span>
                        </div>
                        <h2 className="text-xl font-bold text-gray-800 mt-2">{formation.title}</h2>
                        <p className="text-gray-600 mt-2 flex-grow">{formation.description}</p>
                        {formation.details && (
                            <div className="mt-3 pt-3 border-t border-gray-200 border-dashed">
                                <p className="text-sm text-gray-700">{formation.details}</p>
                            </div>
                        )}
                        <div className="mt-4 pt-4 border-t border-gray-200">
                           <p className="text-sm text-gray-700"><strong>Teacher:</strong> {getTeacherName(formation.teacherId)}</p>
                           <p className="text-sm text-gray-500 mt-1">
                                {formation.studentIds.length} Student{formation.studentIds.length !== 1 ? 's' : ''} Enrolled
                           </p>
                        </div>
                    </div>
                ))}
            </div>
            {isAddModalOpen && (
                <AddCourseModal
                    onClose={() => setIsAddModalOpen(false)}
                    onAddCourse={handleAddFormation}
                    schools={schools}
                    users={users}
                    user={user}
                    context="formation"
                />
            )}
        </div>
    );
};

export default SecretaryFormationsPage;