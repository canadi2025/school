
import React from 'react';
import { useData } from '../../context/DataContext';
import { User, Role } from '../../types';
import PageHeader from '../../components/PageHeader';

interface SecretaryStudentsPageProps {
    user: User;
}

const SecretaryStudentsPage: React.FC<SecretaryStudentsPageProps> = ({ user: currentSecretary }) => {
    const { users } = useData();
    const schoolStudents = users.filter(u => u.schoolId === currentSecretary.schoolId && u.role === Role.STUDENT);

    return (
        <div>
            <PageHeader title="Manage Students" />
             <div className="bg-white shadow-md rounded-lg overflow-hidden">
                <table className="min-w-full leading-normal">
                    <thead>
                        <tr>
                            <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Student Name
                            </th>
                            <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                                Email
                            </th>
                            <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100"></th>
                        </tr>
                    </thead>
                    <tbody>
                        {schoolStudents.map(student => (
                            <tr key={student.id} className="hover:bg-gray-50">
                                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                                    <p className="text-gray-900 whitespace-no-wrap font-semibold">{student.profile.firstName} {student.profile.lastName}</p>
                                </td>
                                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm">
                                    <p className="text-gray-900 whitespace-no-wrap">{student.email}</p>
                                </td>
                                <td className="px-5 py-4 border-b border-gray-200 bg-white text-sm text-right">
                                    <button className="text-primary-600 hover:text-primary-900">View Details</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default SecretaryStudentsPage;
