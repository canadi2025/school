import React from 'react';
import { useData } from '../../context/DataContext';
import { User } from '../../types';
import PageHeader from '../../components/PageHeader';

interface SecretaryClassesPageProps {
    user: User;
}

const SecretaryClassesPage: React.FC<SecretaryClassesPageProps> = ({ user }) => {
    const { courses, users } = useData();
    const schoolCourses = courses.filter(c => c.schoolId === user.schoolId && !c.category);

    const getTeacherName = (teacherId: number) => {
        const teacher = users.find(u => u.id === teacherId);
        return teacher ? `${teacher.profile.firstName} ${teacher.profile.lastName}` : 'N/A';
    };

    return (
        <div>
            <PageHeader title="School Classes" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {schoolCourses.map(course => (
                    <div key={course.id} className="bg-white rounded-lg shadow-md p-6">
                        <h2 className="text-xl font-bold text-gray-800">{course.title}</h2>
                        <p className="text-gray-600 mt-2 h-12 overflow-hidden">{course.description}</p>
                        <div className="mt-4 pt-4 border-t border-gray-200">
                           <p className="text-sm text-gray-700"><strong>Teacher:</strong> {getTeacherName(course.teacherId)}</p>
                           <p className="text-sm text-gray-500 mt-1">
                                {course.studentIds.length} Student{course.studentIds.length !== 1 ? 's' : ''} Enrolled
                           </p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default SecretaryClassesPage;