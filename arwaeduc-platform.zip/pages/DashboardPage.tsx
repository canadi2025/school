import React from 'react';
import { User, Role } from '../types';
import { useData } from '../context/DataContext';
import { useSchoolPermissions } from '../hooks/useSchoolPermissions';
import { UsersIcon, CoursesIcon, SchoolIcon } from '../components/icons/IconComponents';

interface DashboardPageProps {
  user: User;
}

const StatCard: React.FC<{ title: string; value: string | number; color: string }> = ({ title, value, color }) => (
    <div className={`bg-white p-6 rounded-lg shadow-md border-l-4 ${color}`}>
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <p className="mt-2 text-3xl font-bold text-gray-800">{value}</p>
    </div>
);

const UsageBar: React.FC<{ label: string; usage: number; limit: number; icon: React.FC<{className?: string}> }> = ({ label, usage, limit, icon: Icon }) => {
    const percentage = limit > 0 && isFinite(limit) ? (usage / limit) * 100 : 0;
    const isUnlimited = !isFinite(limit);
    const isAtLimit = !isUnlimited && usage >= limit;

    let barColor = 'bg-primary-500';
    if (percentage > 90) barColor = 'bg-red-500';
    else if (percentage > 75) barColor = 'bg-yellow-500';

    return (
        <div>
            <div className="flex justify-between items-center mb-1">
                <div className="flex items-center">
                    <Icon className="w-4 h-4 mr-2 text-gray-500" />
                    <span className="text-sm font-medium text-gray-700">{label}</span>
                </div>
                <span className={`text-sm font-semibold ${isAtLimit ? 'text-red-600' : 'text-gray-600'}`}>
                    {usage} / {isUnlimited ? 'Unlimited' : limit}
                </span>
            </div>
            {!isUnlimited && (
                 <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div className={`${barColor} h-2.5 rounded-full`} style={{ width: `${percentage}%` }}></div>
                </div>
            )}
        </div>
    );
};


const DashboardPage: React.FC<DashboardPageProps> = ({ user }) => {
    const { usage, limits } = useSchoolPermissions(user.schoolId);
    const { users, schools, courses, payments, loading } = useData();
    
    const getStats = () => {
        if (loading) return [];
        switch(user.role) {
            case Role.SUPER_ADMIN:
                return [
                    { title: 'Total Schools', value: schools.length, color: 'border-primary-500' },
                    { title: 'Total Users', value: users.length, color: 'border-indigo-500' },
                    { title: 'Total Courses', value: courses.length, color: 'border-teal-500' },
                    { title: 'Total Revenue', value: `$${payments.reduce((acc, p) => acc + p.amount, 0).toFixed(2)}`, color: 'border-green-500' },
                ];
            
            case Role.ADMIN:
                const schoolUsers = users.filter(u => u.schoolId === user.schoolId);
                const schoolCourses = courses.filter(c => c.schoolId === user.schoolId);
                const schoolUserIds = schoolUsers.map(u => u.id);
                const schoolPayments = payments.filter(p => schoolUserIds.includes(p.userId));
                return [
                    { title: 'School Users', value: schoolUsers.length, color: 'border-indigo-500' },
                    { title: 'School Courses', value: schoolCourses.length, color: 'border-teal-500' },
                    { title: 'School Revenue', value: `$${schoolPayments.reduce((acc, p) => acc + p.amount, 0).toFixed(2)}`, color: 'border-green-500' },
                ];

            case Role.TEACHER: 
                return [
                    { title: 'My Courses', value: courses.filter(c => c.teacherId === user.id).length, color: 'border-teal-500' },
                    { title: 'My Students', value: courses.filter(c => c.teacherId === user.id).reduce((acc, c) => acc + c.studentIds.length, 0), color: 'border-indigo-500' },
                ];
            
            case Role.STUDENT:
                return [
                    { title: 'Enrolled Courses', value: courses.filter(c => c.studentIds.includes(user.id)).length, color: 'border-teal-500' },
                    { title: 'Payments Made', value: payments.filter(p => p.userId === user.id).length, color: 'border-green-500' },
                ];
            
            case Role.SECRETARY:
                return [
                    { title: 'Students in School', value: users.filter(u => u.schoolId === user.schoolId && u.role === Role.STUDENT).length, color: 'border-indigo-500' },
                    { title: 'Courses in School', value: courses.filter(c => c.schoolId === user.schoolId).length, color: 'border-teal-500' },
                ];
            
            case Role.PARENT:
                 return [
                    { title: 'My Children', value: user.profile.childIds?.length || 0, color: 'border-indigo-500' },
                 ];

            default: return [];
        }
    };

    const showUsagePanel = (user.role === Role.ADMIN || user.role === Role.SECRETARY) && limits;

    return (
        <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">Welcome back, {user.profile.firstName}!</h1>
            <p className="text-gray-600 mb-8">Here's a summary of your platform activity.</p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {loading ? <p>Loading stats...</p> : getStats().map(stat => <StatCard key={stat.title} {...stat} />)}
            </div>

            {showUsagePanel && (
                <div className="mt-8">
                    <h2 className="text-xl font-semibold text-gray-800 mb-4">Resource Usage</h2>
                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                            <UsageBar label="Students" usage={usage.students} limit={limits.maxStudents} icon={UsersIcon}/>
                            <UsageBar label="Courses" usage={usage.courses} limit={limits.maxCourses} icon={CoursesIcon}/>
                            <UsageBar label="Teachers" usage={usage.teachers} limit={limits.maxTeachers} icon={SchoolIcon}/>
                            <UsageBar label="Secretaries" usage={usage.secretaries} limit={limits.maxSecretaries} icon={UsersIcon}/>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DashboardPage;
