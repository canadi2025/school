import React, { createContext, useState, useEffect, useContext, useCallback, ReactNode } from 'react';
import * as api from '../services/api';
import { User, School, Course, Payment, SpacePackLimits, SubscriptionPack } from '../types';

interface DataContextState {
    users: User[];
    schools: School[];
    courses: Course[];
    payments: Payment[];
    spacePacks: Record<SubscriptionPack, SpacePackLimits> | null;
    loading: boolean;
    refetchAll: () => Promise<void>;
}

const DataContext = createContext<DataContextState | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [users, setUsers] = useState<User[]>([]);
    const [schools, setSchools] = useState<School[]>([]);
    const [courses, setCourses] = useState<Course[]>([]);
    const [payments, setPayments] = useState<Payment[]>([]);
    const [spacePacks, setSpacePacks] = useState<Record<SubscriptionPack, SpacePackLimits> | null>(null);
    const [loading, setLoading] = useState(true);

    const fetchAllData = useCallback(async () => {
        setLoading(true);
        try {
            const [usersData, schoolsData, coursesData, paymentsData, spacePacksData] = await Promise.all([
                api.getUsers(),
                api.getSchools(),
                api.getCourses(),
                api.getPayments(),
                api.getSpacePacks(),
            ]);
            setUsers(usersData);
            setSchools(schoolsData);
            setCourses(coursesData);
            setPayments(paymentsData);
            setSpacePacks(spacePacksData);
        } catch (error) {
            console.error("Failed to fetch data:", error);
            // Handle error state if necessary
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchAllData();
    }, [fetchAllData]);

    const value = {
        users,
        schools,
        courses,
        payments,
        spacePacks,
        loading,
        refetchAll: fetchAllData,
    };

    return (
        <DataContext.Provider value={value}>
            {children}
        </DataContext.Provider>
    );
};

export const useData = () => {
    const context = useContext(DataContext);
    if (context === undefined) {
        throw new Error('useData must be used within a DataProvider');
    }
    return context;
};
