

import {
    User,
    School,
    Course,
    Payment,
    Role,
    SubscriptionPack,
    SubscriptionStatus,
    PaymentStatus,
    SpacePackLimits,
    Profile,
    FormationCategory
} from '../types';
import { sendWelcomeEmail, notifyAdminOfNewUser } from './notification';

// Mock Data Store
let nextUserId = 1;
let nextSchoolId = 1;
let nextCourseId = 1;
let nextPaymentId = 1;
let nextProfileId = 1;

let schools: School[] = [
    { id: nextSchoolId++, name: 'Innovate Language Institute', address: '123 Tech Ave, Silicon Valley', subscriptionPack: SubscriptionPack.BUSINESS, subscriptionStatus: SubscriptionStatus.ACTIVE, featureOverrides: { parentDashboard: true } },
    { id: nextSchoolId++, name: 'Future Leaders Academy', address: '456 Knowledge Blvd, Boston', subscriptionPack: SubscriptionPack.STARTER, subscriptionStatus: SubscriptionStatus.ACTIVE },
    { id: nextSchoolId++, name: 'Simple Start School', subscriptionPack: SubscriptionPack.SIMPLE, subscriptionStatus: SubscriptionStatus.PENDING },
];

let users: User[] = [];
let courses: Course[] = [];
let payments: Payment[] = [];

let spacePacks: Record<SubscriptionPack, SpacePackLimits> = {
    [SubscriptionPack.SIMPLE]: { maxStudents: 50, maxCourses: 10, maxTeachers: 5, maxSecretaries: 1, adminDashboard: true, parentDashboard: false, features: ['Basic Reporting'] },
    [SubscriptionPack.STARTER]: { maxStudents: 200, maxCourses: 50, maxTeachers: 20, maxSecretaries: 3, adminDashboard: true, parentDashboard: true, features: ['Advanced Reporting', 'Email Support'] },
    [SubscriptionPack.BUSINESS]: { maxStudents: Infinity, maxCourses: Infinity, maxTeachers: Infinity, maxSecretaries: Infinity, adminDashboard: true, parentDashboard: true, features: ['Advanced Reporting', 'Priority Support', 'API Access'] },
};


// Helper to create users
const createUserInternal = (role: Role, schoolId: number | undefined, profileData: Partial<Omit<Profile, 'id' | 'userId'>> & { firstName: string, lastName: string, email: string }): User => {
    const profile: Profile = {
        id: nextProfileId++,
        userId: nextUserId,
        firstName: profileData.firstName,
        lastName: profileData.lastName,
        phone: profileData.phone,
        address: profileData.address,
        socialMediaLink: profileData.socialMediaLink,
        documents: profileData.documents,
        childIds: profileData.childIds,
    };
    const user: User = {
        id: nextUserId++,
        email: profileData.email,
        role,
        schoolId,
        profile,
        createdAt: new Date().toISOString(),
    };
    users.push(user);
    return user;
};


// Create sample users
const superAdmin = createUserInternal(Role.SUPER_ADMIN, undefined, { firstName: 'Super', lastName: 'Admin', email: 'super@edusaas.com' });
const school1Admin = createUserInternal(Role.ADMIN, 1, { firstName: 'Alice', lastName: 'Admin', email: 'alice@innovate.com' });
const school2Admin = createUserInternal(Role.ADMIN, 2, { firstName: 'Bob', lastName: 'Manager', email: 'bob@futureleaders.com' });

const school1Sec = createUserInternal(Role.SECRETARY, 1, { firstName: 'Charlie', lastName: 'Secretary', email: 'charlie@innovate.com' });
const school2Sec = createUserInternal(Role.SECRETARY, 2, { firstName: 'Diana', lastName: 'Clerk', email: 'diana@futureleaders.com' });

const school1Teacher1 = createUserInternal(Role.TEACHER, 1, { firstName: 'David', lastName: 'Teacher', email: 'david@innovate.com', phone: '111-222-3333', address: 'Teacher Address 1', socialMediaLink: 'linkedin.com/david', documents: ['CV.pdf', 'Certificate.pdf'] });
const school1Teacher2 = createUserInternal(Role.TEACHER, 1, { firstName: 'Eve', lastName: 'Professor', email: 'eve@innovate.com' });
const school2Teacher1 = createUserInternal(Role.TEACHER, 2, { firstName: 'Frank', lastName: 'Instructor', email: 'frank@futureleaders.com' });

const school1Student1 = createUserInternal(Role.STUDENT, 1, { firstName: 'Grace', lastName: 'Student', email: 'grace@example.com' });
const school1Student2 = createUserInternal(Role.STUDENT, 1, { firstName: 'Heidi', lastName: 'Learner', email: 'heidi@example.com' });
const school2Student1 = createUserInternal(Role.STUDENT, 2, { firstName: 'Ivan', lastName: 'Scholar', email: 'ivan@example.com' });

const school1Parent1 = createUserInternal(Role.PARENT, 1, { firstName: 'Mallory', lastName: 'Parent', email: 'mallory@example.com', childIds: [school1Student1.id] });
const school1Parent2 = createUserInternal(Role.PARENT, 1, { firstName: 'Trent', lastName: 'Guardian', email: 'trent@example.com', childIds: [school1Student2.id] });

// Sample Courses
courses = [
    { id: nextCourseId++, title: 'Advanced English', description: 'Master the English language.', schoolId: 1, teacherId: school1Teacher1.id, studentIds: [school1Student1.id, school1Student2.id], schedule: [new Date().toISOString()] },
    { id: nextCourseId++, title: 'Beginner Spanish', description: 'Learn the basics of Spanish.', schoolId: 1, teacherId: school1Teacher2.id, studentIds: [school1Student1.id], schedule: [] },
    { id: nextCourseId++, title: 'Leadership 101', description: 'Fundamentals of being a good leader.', schoolId: 2, teacherId: school2Teacher1.id, studentIds: [school2Student1.id], schedule: [] },
    { id: nextCourseId++, title: 'Math Support', description: 'Support for school math program.', schoolId: 1, teacherId: school1Teacher1.id, studentIds: [], schedule: [], category: FormationCategory.SCOLAIRE_SOUTIEN, details: 'For grade 10 students' },
    { id: nextCourseId++, title: 'Public Speaking Workshop', description: 'Become a confident speaker.', schoolId: 1, teacherId: school1Teacher2.id, studentIds: [school1Student2.id], schedule: [], category: FormationCategory.TRAINING },
];

// Sample Payments
payments = [
    { id: nextPaymentId++, userId: school1Student1.id, amount: 250, currency: 'USD', status: PaymentStatus.COMPLETED, createdAt: new Date().toISOString() },
    { id: nextPaymentId++, userId: school1Student2.id, amount: 300, currency: 'USD', status: PaymentStatus.COMPLETED, createdAt: new Date().toISOString() },
    { id: nextPaymentId++, userId: school2Student1.id, amount: 450, currency: 'USD', status: PaymentStatus.PENDING, createdAt: new Date().toISOString() },
];


// --- API Functions ---
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

export const getUsers = async (): Promise<User[]> => { await delay(200); return [...users]; };
export const getSchools = async (): Promise<School[]> => { await delay(200); return [...schools]; };
export const getCourses = async (): Promise<Course[]> => { await delay(200); return [...courses]; };
export const getPayments = async (): Promise<Payment[]> => { await delay(200); return [...payments]; };
export const getSpacePacks = async (): Promise<Record<SubscriptionPack, SpacePackLimits>> => { await delay(200); return JSON.parse(JSON.stringify(spacePacks)); };

type CreateSchoolData = { name: string; address?: string; pack: SubscriptionPack; featureOverrides: School['featureOverrides'] };
export const createSchool = async (schoolData: CreateSchoolData): Promise<School> => {
    await delay(500);
    const newSchool: School = {
        id: nextSchoolId++,
        name: schoolData.name,
        address: schoolData.address,
        subscriptionPack: schoolData.pack,
        subscriptionStatus: SubscriptionStatus.PENDING,
        featureOverrides: schoolData.featureOverrides
    };
    schools.push(newSchool);
    return newSchool;
};

export const updateSchool = async (schoolId: number, schoolData: { name: string, address?: string }): Promise<School> => {
    await delay(500);
    const schoolIndex = schools.findIndex(s => s.id === schoolId);
    if (schoolIndex === -1) throw new Error('School not found');
    schools[schoolIndex] = { ...schools[schoolIndex], ...schoolData };
    return schools[schoolIndex];
};

export const enrollStudent = async (courseId: number, studentId: number): Promise<Course> => {
    await delay(300);
    const course = courses.find(c => c.id === courseId);
    if (!course) throw new Error('Course not found');
    if (!course.studentIds.includes(studentId)) {
        course.studentIds.push(studentId);
    }
    return course;
};

export const updateSubscription = async (schoolId: number, pack: SubscriptionPack, status: SubscriptionStatus, featureOverrides: School['featureOverrides']): Promise<School> => {
    await delay(500);
    const school = schools.find(s => s.id === schoolId);
    if (!school) throw new Error('School not found');
    school.subscriptionPack = pack;
    school.subscriptionStatus = status;
    school.featureOverrides = featureOverrides;
    return school;
};

export const createUser = async (userData: { email: string; role: Role; schoolId?: number, firstName: string, lastName: string, profile: Omit<Profile, 'id'|'userId'|'firstName'|'lastName'> }): Promise<User> => {
    await delay(500);
    const profile: Profile = {
        id: nextProfileId++,
        userId: nextUserId,
        ...userData.profile,
        firstName: userData.firstName,
        lastName: userData.lastName
    };
    const newUser: User = {
        id: nextUserId++,
        email: userData.email,
        role: userData.role,
        schoolId: userData.schoolId,
        profile,
        createdAt: new Date().toISOString(),
    };
    users.push(newUser);

    // --- Notification Logic ---
    // 1. Send welcome email to the new user
    sendWelcomeEmail(newUser);

    // 2. Notify the relevant admin
    const superAdmin = users.find(u => u.role === Role.SUPER_ADMIN);
    if (newUser.schoolId) {
        // Find the admin of the school
        const schoolAdmin = users.find(u => u.schoolId === newUser.schoolId && u.role === Role.ADMIN);
        if (schoolAdmin) {
            notifyAdminOfNewUser(schoolAdmin, newUser);
        } else if (superAdmin) {
            // If no school admin, notify the super admin
            notifyAdminOfNewUser(superAdmin, newUser);
        }
    } else if (superAdmin) {
        // If user is not associated with a school (e.g., created by super admin), notify super admin
        notifyAdminOfNewUser(superAdmin, newUser);
    }
    // --- End of Notification Logic ---

    return newUser;
};

export const deleteUser = async (userId: number): Promise<void> => {
    await delay(500);
    users = users.filter(u => u.id !== userId);
};

export const createCourse = async (courseData: Omit<Course, 'id'|'studentIds'>): Promise<Course> => {
    await delay(500);
    const newCourse: Course = {
        id: nextCourseId++,
        ...courseData,
        studentIds: [],
    };
    courses.push(newCourse);
    return newCourse;
};

export const deleteCourse = async (courseId: number): Promise<void> => {
    await delay(500);
    courses = courses.filter(c => c.id !== courseId);
};

export const updateSpacePack = async (pack: SubscriptionPack, limits: SpacePackLimits): Promise<SpacePackLimits> => {
    await delay(500);
    spacePacks[pack] = limits;
    return spacePacks[pack];
};