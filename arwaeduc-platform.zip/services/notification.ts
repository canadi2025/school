import { User } from '../types';

/**
 * Simulates sending an email. In a real application, this would use an email service.
 * A new user creation event triggers two notifications: a welcome email to the new user,
 * and a notification to the relevant admin.
 */
const sendEmail = (to: string, subject: string, body: string) => {
  console.log('--- Email Sent ---');
  console.log(`To: ${to}`);
  console.log(`Subject: ${subject}`);
  console.log(`Body: \n${body}`);
  console.log('--------------------');
};

/**
 * Sends a welcome email to a newly created user.
 * @param newUser The user object of the newly created user.
 */
export const sendWelcomeEmail = (newUser: User) => {
  const subject = 'Welcome to EduSaaS Platform!';
  const body = `Hi ${newUser.profile.firstName},\n\nWelcome to the EduSaaS Platform! Your account has been successfully created with the role of ${newUser.role.toLowerCase()}.\n\nYou can now log in and explore the platform.\n\nBest regards,\nThe EduSaaS Team`;
  sendEmail(newUser.email, subject, body);
};

/**
 * Notifies an admin about a new user being created.
 * @param admin The admin user to notify.
 * @param newUser The newly created user.
 */
export const notifyAdminOfNewUser = (admin: User, newUser: User) => {
  const subject = `New User Created: ${newUser.profile.firstName} ${newUser.profile.lastName}`;
  const body = `Hi ${admin.profile.firstName},\n\nA new user has been created in the system:\n\nName: ${newUser.profile.firstName} ${newUser.profile.lastName}\nEmail: ${newUser.email}\nRole: ${newUser.role.toLowerCase()}\nSchool ID: ${newUser.schoolId || 'N/A'}\n\nThis is for your information.\n\nBest regards,\nThe EduSaaS System`;
  sendEmail(admin.email, subject, body);
};
